# dep

Dependency parsing datasets.

```{toctree}
conll_dataset
resources
```

