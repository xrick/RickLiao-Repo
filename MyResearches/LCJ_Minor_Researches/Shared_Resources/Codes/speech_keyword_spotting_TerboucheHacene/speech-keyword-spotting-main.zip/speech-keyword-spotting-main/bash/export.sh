#!/bin/bash



poetry run python scripts/export/export.py \
    --checkpoint_dir "custom_wav2vec2_2022-11-21_21-34-03/" \

