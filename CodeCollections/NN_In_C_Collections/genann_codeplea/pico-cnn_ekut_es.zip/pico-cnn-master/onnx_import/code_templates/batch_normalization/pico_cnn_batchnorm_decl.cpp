    pico_cnn::naive::BatchNormalization *{{identifier}}_layer;
