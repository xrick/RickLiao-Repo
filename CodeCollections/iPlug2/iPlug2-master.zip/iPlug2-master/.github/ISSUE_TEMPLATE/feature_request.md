---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

iPlug2 is the result of the hard work of a couple of people over many years. It is provided for free.

Do you know you can support the project financially? If you would like to sponsor the project so we can spend time on a particular feature, please let us know.

You can also try to fix and add things yourself, rather than expecting others to do things for you. We really appreciate all contributions.
