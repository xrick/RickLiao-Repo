    pico_cnn::naive::Clip *{{identifier}}_layer;
