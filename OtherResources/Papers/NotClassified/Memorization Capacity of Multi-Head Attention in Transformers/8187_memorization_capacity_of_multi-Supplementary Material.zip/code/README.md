# Instructions on how to reproduce the code:

First, install the required libraries:

```bat
pip3 install -r requirements.txt
```

In order to reproduce the experiments, you need to run the bash file named 'reproduce.sh'.

```bat
bash reproduce.sh
```

Note that each experiment in reproduce.sh is run for only one seed. Running for 6 seeds takes approximately 20 GPU days using a V100 GPU.

For the ViT/BERT/GPT2 analysis, please refer to the notebooks in the `analysis` directory.

