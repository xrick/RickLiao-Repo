swipe_slim
==============

.. automodule:: libf0.swipe_slim
    :members:
    :undoc-members:
