---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:

*Important:* Please provide a self-contained example. A colab may also be ok.

**Version**
Please state the version of dtw-python (as reported by pip or conda).
