# io_util

```{eval-rst}

.. currentmodule:: hanlp.utils

.. automodule:: hanlp.utils.io_util
	:members:

```
