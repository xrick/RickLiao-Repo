Classifiers implementation , initial step for gender and then for healthy or not  cases.

- Gaussian Mixture Models  
- K-nearest Neighbours  
- Logistic Regression  
- Support Vector Machine  
- Linear Discriminant Analysis  
- Decision Tree Classifier  
- GaussianNB 
- Neural Networks  

Further elaboration took place :
- GMMs  
- KNN  
- LR
- SVM
