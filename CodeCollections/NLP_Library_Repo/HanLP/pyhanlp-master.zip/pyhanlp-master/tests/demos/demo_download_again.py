# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2019-11-15 11:17
# 演示如何通过自动下载修复失败的的安装
from pyhanlp.static import install_hanlp_jar, install_hanlp_data

install_hanlp_jar()
install_hanlp_data()
