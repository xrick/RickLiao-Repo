#include <stdio.h>

int main(void)
{
	int x = 10;
	int y = 20;
	if (x == y)
	{
		printf("The values are equal.\n");
	}
	else
	{
		printf("The values are not equal.\n");
	}
}