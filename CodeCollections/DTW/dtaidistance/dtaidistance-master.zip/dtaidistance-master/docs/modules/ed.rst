
.. automodule:: dtaidistance.ed
   :members:
