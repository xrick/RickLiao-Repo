#ifndef ARRAYTOOLBOX_H
#define ARRAYTOOLBOX_H

#include "wav2sig.h"
#include "delay.h"
#include "HandyFunctions.h"
#include "speedofsound.h"
#include "atmAtten.h"
#include "regmics.h"

#endif