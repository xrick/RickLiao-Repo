int main(void)
{
	char mychar;
	mychar = 'a';
}