# Named Entity Recognition

## Chinese

```{toctree}
pku
msra
```

## Multilingual

```{toctree}
ontonotes
```
