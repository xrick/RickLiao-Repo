var searchData=
[
  ['frac_20limits',['FRAC Limits',['../group__frac__limits.html',1,'']]],
  ['fixed_20point_20arithmetic',['Fixed point arithmetic',['../group__fxp__arith.html',1,'']]],
  ['fixed_20point_20numbers',['Fixed point numbers',['../group__fxp__class.html',1,'']]],
  ['function_2dgenerating_20macros',['Function-generating macros',['../group__fxp__fmacros.html',1,'']]],
  ['function_2dgenerating_20macros_2e',['Function-generating macros.',['../group__fxp__vec__fmacros.html',1,'']]],
  ['fxp_5fwidth',['Fxp_width',['../group__fxp__width.html',1,'']]]
];
