#include <stdio.h>

int main(void)
{
	char c = 'a';
	int x = 123;
	float f = 123.456f;
	double d = 789.101112;
	printf("%c\n", c);
	printf("%d\n", x);
	printf("%f\n", f);
	printf("%f\n", d);
}