#pragma once

NS_HWM_BEGIN

wxDialog * CreateSettingDialog(wxWindow *parent);

NS_HWM_END
