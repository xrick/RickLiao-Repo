from .utils import init_logger

init_logger()
