rm *.caffemodel
rm *.solverstate
rm ./log/caffe.*
