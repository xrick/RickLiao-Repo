# biaffine_ner

Biaffine Named Entity Recognition.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.ner.biaffine_ner.BiaffineNamedEntityRecognition
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
