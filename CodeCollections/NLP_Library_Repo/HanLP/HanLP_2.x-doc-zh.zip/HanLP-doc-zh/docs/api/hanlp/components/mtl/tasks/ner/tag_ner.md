# tag_ner

Tagging based Named Entity Recognition.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.ner.tag_ner.TaggingNamedEntityRecognition
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
