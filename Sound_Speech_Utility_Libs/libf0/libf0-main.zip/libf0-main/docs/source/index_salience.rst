salience
==============

.. automodule:: libf0.salience
    :members:
    :undoc-members:
