var searchData=
[
  ['vec3_5fs16',['vec3_s16',['../group__fxp__width.html#gadd5bc49a9fa5468bb005357f95a24c00',1,'vector_types.h']]],
  ['vec3_5fs32',['vec3_s32',['../group__fxp__width.html#gabb355f25849cbbbc73fe216de2ddbc6a',1,'vector_types.h']]]
];
