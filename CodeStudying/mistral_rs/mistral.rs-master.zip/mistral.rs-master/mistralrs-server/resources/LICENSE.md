[Rust Logo](https://www.rust-lang.org/logos/rust-logo-32x32.png)(`rust-logo-32x32.png`) by Rust Foundation is licensed under
[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/?ref=chooser-v1).

This project is not affiliated with or endorsed by the Rust Foundation.