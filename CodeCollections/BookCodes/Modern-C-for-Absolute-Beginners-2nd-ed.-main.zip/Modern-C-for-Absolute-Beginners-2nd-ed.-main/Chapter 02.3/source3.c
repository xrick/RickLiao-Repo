#include <stdio.h>

int main(void)
{
	printf("Hello World!\n");
	printf("This is a new line!");
}