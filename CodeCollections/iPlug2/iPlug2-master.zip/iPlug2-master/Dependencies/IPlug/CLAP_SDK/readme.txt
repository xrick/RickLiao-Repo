Place the clap repo from free-audio here

https://github.com/free-audio/clap

This folder (CLAP_SDK) should be the root of the repo
