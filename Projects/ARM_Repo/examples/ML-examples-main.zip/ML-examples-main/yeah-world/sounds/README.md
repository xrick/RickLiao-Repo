Attribution:
1_person_cheering-Jett_Rifkin-1851518140.wav - Jett Rifkin, http://soundbible.com/2103-1-Person-Cheering.html
Applause-SoundBible.com-151138312.wav - Mike Koenig, http://soundbible.com/988-Applause.html
5_Sec_Crowd_Cheer-Mike_Koenig-1562033255.wav - Mike Koenig, http://soundbible.com/1700-5-Sec-Crowd-Cheer.html

More are available for personal use from http://soundbible.com/suggest.php?q=cheer

