.. _ref-basis:

deeptime.basis
==============

The *basis* package contains transformations of data into different bases for easier featurization.

.. automodule:: deeptime.basis

.. toctree::
   :maxdepth: 1
