#include <stdio.h>
#include <limits.h>

int main(void)
{
	printf("The minimum value an int can store is: %d\n", INT_MIN);
	printf("The maximum value an int can store is: %d\n", INT_MAX);
}