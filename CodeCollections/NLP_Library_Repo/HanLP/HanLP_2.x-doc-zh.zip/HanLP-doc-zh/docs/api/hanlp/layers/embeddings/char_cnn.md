# char_cnn


```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.char_cnn.CharCNN
	:members:

.. autoclass:: hanlp.layers.embeddings.char_cnn.CharCNNEmbedding
	:members:

```
