#include <stdio.h>

int main(void)
{
	int x;
	int y;
	x = 123;
	y = x;
	printf("%d", y);
}