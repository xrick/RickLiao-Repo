# tasks

Multi-Task Learning (MTL) tasks.

```{toctree}
task
constituency
dep
sdp
ud
lem
pos
tok
ner/index
srl/index
```

