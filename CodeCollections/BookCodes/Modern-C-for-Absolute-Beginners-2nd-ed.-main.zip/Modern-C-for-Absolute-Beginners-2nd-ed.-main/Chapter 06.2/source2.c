#include <stdio.h>

int main(void)
{
	int x = 10;
	int y = 30;
	double d = x / y;
	printf("The result is: %f\n", d);
}