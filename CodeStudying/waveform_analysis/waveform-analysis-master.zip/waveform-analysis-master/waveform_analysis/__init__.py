"""
A collection of functions and scripts for analyzing waveforms, especially audio

https://github.com/endolith/waveform-analysis
"""

from .weighting_filters import *
