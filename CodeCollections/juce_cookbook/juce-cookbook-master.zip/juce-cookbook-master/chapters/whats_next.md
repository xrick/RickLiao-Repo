# What next

- Read the docs
- Read the source
- Read other app written in JUCE
  - modEQ
  - helm
  - temper

## Related resources

- Faust
  - YouTube
- `std::audio`
