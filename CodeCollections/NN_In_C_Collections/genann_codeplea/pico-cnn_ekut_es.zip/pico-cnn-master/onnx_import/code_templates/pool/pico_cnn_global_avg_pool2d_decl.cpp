    pico_cnn::naive::GlobalAveragePooling *{{identifier}}_layer;
