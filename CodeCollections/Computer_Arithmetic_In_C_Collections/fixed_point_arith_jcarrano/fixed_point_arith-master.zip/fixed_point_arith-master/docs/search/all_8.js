var searchData=
[
  ['macros',['Macros',['../group__fxp__macros.html',1,'']]],
  ['make_5fvec_5felem_5ff',['MAKE_VEC_ELEM_F',['../group__fxp__vec__fmacros.html#gac9728a4f733ffabbceb397d913561f42',1,'vector.h']]],
  ['make_5fvec_5fscalar_5ff',['MAKE_VEC_SCALAR_F',['../group__fxp__vec__fmacros.html#gabb9c099d743c418efe07fa405b522457',1,'vector.h']]],
  ['make_5fvec_5fscalar_5ff2',['MAKE_VEC_SCALAR_F2',['../group__fxp__vec__fmacros.html#ga53d40f60533d9fc99bbce57b9efefbec',1,'vector.h']]],
  ['make_5fvec_5fvec_5ff',['MAKE_VEC_VEC_F',['../group__fxp__vec__fmacros.html#ga1707c5c06e3351a794e528d21213ab85',1,'vector.h']]],
  ['make_5fvec_5fvec_5ff3',['MAKE_VEC_VEC_F3',['../group__fxp__vec__fmacros.html#ga97443fea4fc7699c4f1f4aa9f9a2d396',1,'vector.h']]],
  ['mfrac',['mfrac',['../group__fxp__class.html#structmfrac',1,'']]],
  ['mfrac_5f1_5fv',['MFRAC_1_V',['../group__mfrac__limits.html#ga170ab5b29180a04d875c76a9b5a091db',1,'types.h']]],
  ['mfrac_5fbase',['mfrac_base',['../group__fxp__class.html#ga4e4b8e4cbca87352fedf414558a50aeb',1,'types.h']]],
  ['mfrac_5fbit',['MFRAC_BIT',['../group__fxp__class.html#ga6e1e4d47d67e443decfacbbf1e02eb21',1,'types.h']]],
  ['mfrac_20limits',['MFRAC Limits',['../group__mfrac__limits.html',1,'']]],
  ['mfrac_5fmax_5fv',['MFRAC_MAX_V',['../group__mfrac__limits.html#ga27af15f604250524a556999717bbc6c1',1,'types.h']]],
  ['mfrac_5fmin_5fv',['MFRAC_MIN_V',['../group__mfrac__limits.html#ga0e3f27ef80c1eecaa15bb4184b243c33',1,'types.h']]],
  ['mfrac_5fminus1_5fv',['MFRAC_minus1_V',['../group__mfrac__limits.html#gacdb0d4cc4374d089f2b9cd5f18d2b70a',1,'types.h']]],
  ['mvec3',['mvec3',['../group__fxp__vec.html#structmvec3',1,'']]]
];
