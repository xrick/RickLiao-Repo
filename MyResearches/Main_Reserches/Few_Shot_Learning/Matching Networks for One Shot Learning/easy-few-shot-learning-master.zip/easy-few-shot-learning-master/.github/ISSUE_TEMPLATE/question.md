---
name: Question
about: Any question about how to use EasyFSL?
title: ''
labels: question
assignees: ''

---

**Problem**
What do you want to do? What is blocking you?

**Considered solutions**
What have you tried but didn't work?

**How can we help**
Be as clear and concise as possible so we can help you in the most efficient way.
