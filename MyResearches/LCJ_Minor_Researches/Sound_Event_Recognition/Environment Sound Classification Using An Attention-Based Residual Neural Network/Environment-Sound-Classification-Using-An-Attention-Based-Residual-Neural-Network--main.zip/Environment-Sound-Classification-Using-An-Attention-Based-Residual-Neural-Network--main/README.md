# Environment Sound Classification Using An Attention-Based Residual Neural Network

