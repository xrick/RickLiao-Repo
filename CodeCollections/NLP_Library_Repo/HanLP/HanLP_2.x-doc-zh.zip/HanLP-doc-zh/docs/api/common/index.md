# hanlp_common

Common APIs shared between `hanlp` and `restful`.

```{toctree}
document
conll
configurable
constant
```

