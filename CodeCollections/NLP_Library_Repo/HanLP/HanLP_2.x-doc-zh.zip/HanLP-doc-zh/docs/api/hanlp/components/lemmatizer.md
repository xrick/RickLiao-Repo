# lemmatizer

```{eval-rst}
.. currentmodule:: hanlp.components.lemmatizer

.. autoclass:: TransformerLemmatizer
	:members:

```
