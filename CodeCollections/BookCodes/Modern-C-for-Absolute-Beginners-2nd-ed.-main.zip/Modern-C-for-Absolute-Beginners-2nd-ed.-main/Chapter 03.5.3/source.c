int main(void)
{
	long double mylongdouble;
	mylongdouble = 123456.789l;
}