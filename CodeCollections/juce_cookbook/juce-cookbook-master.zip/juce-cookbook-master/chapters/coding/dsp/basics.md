# DSP Basics

- DSP module
  - Gain example
  - Compressor example
