.. _ref-covariance:

deeptime.covariance
===================
The *covariance* package contains algorithms that can measure covariances for time series data.

.. automodule:: deeptime.covariance

.. toctree::
   :maxdepth: 1
