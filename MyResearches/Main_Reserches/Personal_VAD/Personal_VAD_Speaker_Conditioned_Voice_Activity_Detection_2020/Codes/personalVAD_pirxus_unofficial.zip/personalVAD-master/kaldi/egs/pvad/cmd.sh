train_cmd="run.pl"
decode_cmd="run.pl"
