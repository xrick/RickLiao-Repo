---
title: "Contact"
permalink: /contact/
---

You can reach out to us by email: `firstname (dot) lastname (at) mila (dot) quebec`

If you have any question, bug report or would like to contribute to the code, please open an issue in the project repository.

