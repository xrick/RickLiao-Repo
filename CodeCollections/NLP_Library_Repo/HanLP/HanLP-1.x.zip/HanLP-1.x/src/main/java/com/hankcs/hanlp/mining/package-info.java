/*
 * <author>Hankcs</author>
 * <email>me@hankcs.com</email>
 * <create-date>2017-11-02 11:18</create-date>
 *
 * <copyright file="package-info.java" company="码农场">
 * Copyright (c) 2017, 码农场. All Right Reserved, http://www.hankcs.com/
 * This source is subject to Hankcs. Please contact Hankcs to get more information.
 * </copyright>
 */
/**
 * 这个包下面是一些文本挖掘工具（主要是无监督方法）
 */
package com.hankcs.hanlp.mining;