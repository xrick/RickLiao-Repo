
    {{identifier}}_layer = new pico_cnn::naive::Softmax("{{name}}", 0, pico_cnn::op_type::Softmax);
