.. py:module:: torchaudio.prototype.transforms

torchaudio.prototype.transforms
===============================

.. currentmodule:: torchaudio.prototype.transforms

.. autosummary::
    :toctree: generated
    :nosignatures:

    BarkScale
    BarkSpectrogram
    ChromaScale
    ChromaSpectrogram
    InverseBarkScale
