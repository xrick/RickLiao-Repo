component
=================

.. currentmodule:: hanlp.common

.. autoclass:: hanlp.common.component.Component
	:members:
