#include <stdio.h>

int main(void)
{
	unsigned short x;
	x = 1234u;
	printf("The value of an unsigned short integer is: %hu\n", x);
}