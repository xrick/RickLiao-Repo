The images used for this repository.
