# hanlp_trie

HanLP trie/dictionary interface and referential implementation.

```{toctree}
trie
dictionary
```

