    delete {{identifier}}_layer;
