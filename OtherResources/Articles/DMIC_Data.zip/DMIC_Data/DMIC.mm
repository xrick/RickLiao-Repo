<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1576113770079" ID="ID_985092278" MODIFIED="1576115206097">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      DMIC
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1576113799165" ID="ID_1209342127" MODIFIED="1576115248260" POSITION="right" TEXT="&#x611f;&#x6e2c;&#x5143;&#x4ef6;"/>
<node CREATED="1576114069846" ID="ID_1521770749" MODIFIED="1576114074433" POSITION="left" TEXT="Terms">
<node CREATED="1576114132042" ID="ID_800739590" MODIFIED="1576114136542" TEXT="AOP"/>
</node>
</node>
</map>
