# Putonghua IPA Converter [![](https://github.com/nk2028/putonghua-ipa-converter/workflows/Build/badge.svg)](https://github.com/nk2028/putonghua-ipa-converter/actions?query=workflow%3ABuild)

Convert Chinese texts to its Putonghua pronunciation in IPA form.

Site: <https://nk2028.shn.hk/putonghua-ipa-converter/>.
