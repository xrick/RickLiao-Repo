
豆瓣API的sign值生成


```

必须要保证签名和UA正确


完整工程是一个使用maven构建的servlet程序，用idea导入即可


可以打包后丢到 tomcat\webapps 的容器中部署