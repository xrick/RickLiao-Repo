# rnn_ner

Tagging based Named Entity Recognition.

```{eval-rst}
.. currentmodule:: hanlp.components.ner.rnn_ner

.. autoclass:: hanlp.components.ner.rnn_ner.RNNNamedEntityRecognizer
	:members:

```
