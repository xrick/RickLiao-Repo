#!/usr/bin/env python
"""Version info"""

short_version = "0.1"
version = "0.1.2"
