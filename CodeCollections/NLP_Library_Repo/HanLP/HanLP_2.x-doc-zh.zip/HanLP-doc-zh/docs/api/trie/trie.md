# trie

```{eval-rst}
.. currentmodule:: hanlp_trie

.. autoclass:: hanlp_trie.trie.Node
	:members:

.. autoclass:: hanlp_trie.trie.Trie
	:members:
```
