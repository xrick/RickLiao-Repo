# classifiers

```{eval-rst}
.. currentmodule:: hanlp.components.classifiers

.. autoclass:: hanlp.components.classifiers.transformer_classifier.TransformerClassifier
	:members:

```
