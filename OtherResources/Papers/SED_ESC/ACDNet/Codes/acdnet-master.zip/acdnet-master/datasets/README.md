# Please do not remove this folder.
Without this folder, dataset preparation will be failed. The data for test and augmentation is kept here.
