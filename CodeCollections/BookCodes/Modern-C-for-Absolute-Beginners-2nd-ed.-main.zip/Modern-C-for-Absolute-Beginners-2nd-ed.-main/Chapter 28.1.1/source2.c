#include <stdio.h>

int main(void)
{
	printf("Enter an integer number: ");
	int x;
	scanf("%d", &x);
	printf("You entered: %d\n", x);
}