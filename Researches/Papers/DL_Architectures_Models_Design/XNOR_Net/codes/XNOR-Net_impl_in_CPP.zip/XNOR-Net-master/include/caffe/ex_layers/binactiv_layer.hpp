#ifndef CAFFE_BINACTIV_LAYER_HPP_
#define CAFFE_BINACTIV_LAYER_HPP_

#include <vector>

#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"
#include "caffe/layers/conv_layer.hpp"

namespace caffe {

/**
 * @brief Takes a Blob and slices it along either the num or channel dimension,
 *        outputting multiple sliced Blob results.
 *
 * TODO(dox): thorough documentation for Forward, Backward, and proto params.
 */
template <typename Dtype>
class BinActivLayer : public Layer<Dtype> {
 public:
  explicit BinActivLayer(const LayerParameter& param)
      : Layer<Dtype>(param) {}
  virtual void LayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  virtual void Reshape(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);

  virtual inline const char* type() const { return "BinActiv"; }

 protected:
  virtual void Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  virtual void Forward_gpu(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top);
  virtual void Backward_cpu(const vector<Blob<Dtype>*>& top,
      const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom);
  virtual void Backward_gpu(const vector<Blob<Dtype>*>& top,
      const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom);

  /// The internal Convolution layer 
  shared_ptr<Layer<Dtype> > convolution_layer_;
  vector<Blob<Dtype>*> convolution_bottom_vec_;
  shared_ptr<Blob<Dtype> >  convolution_bottom_shared_;
  vector<Blob<Dtype>*> convolution_top_vec_;
  shared_ptr<Blob<Dtype> >  convolution_top_shared_;
};

}  // namespace caffe

#endif  // CAFFE_BINACTIV_LAYER_HPP_
