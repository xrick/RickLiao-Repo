#include "myutils.h"

void myFunction()
{
	printf("Declared in a header file and defined in a source file.\n");
}