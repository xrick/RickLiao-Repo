.. wavfile documentation master file, created by
   sphinx-quickstart on Sun Aug 21 17:26:00 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Python wavfile package
===================================

.. toctree::
   :maxdepth: 10
   :caption: Contents:

   readme
   wavfile/wavfile


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
