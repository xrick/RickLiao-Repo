# Changelog

## [1.0.4] - 2022-07-19

### Added
* Changelog

### Changed
* log a test call to pinyin2ipa() to the console in test/test_bundle.html
* updated pinyin-separate and all other dependencies except eslint and eslint-config-airbnb due to major changes

[1.0.4]: https://github.com/Connum/npm-pinyin2ipa/compare/1.0.2...1.0.4
