    pico_cnn::naive::LRN *{{identifier}}_layer;
