#!/usr/bin/env python

import sys
import re
import os
import csv
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
from datasets import load_from_disk, Dataset
from sklearn import metrics
from transformers import Wav2Vec2CTCTokenizer, Wav2Vec2Processor, Wav2Vec2ForCTC
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

PHONEME_CONFUSION_MAP = {
    # Stops
    "p": ["b", "m"], "b": ["p", "m"],
    "t": ["d", "ɾ", "n"], "d": ["t", "ɾ", "n"],
    "k": ["g", "ŋ"], "g": ["k", "ŋ"],
    "ʔ": [],
    # Fricatives
    "f": ["v"], "v": ["f"],
    "θ": ["ð", "f"], "ð": ["θ", "v", "d"],
    "s": ["z", "ʃ"], "z": ["s", "ʒ"],
    "ʃ": ["ʒ", "tʃ", "s"], "ʒ": ["ʃ", "dʒ"],
    # Affricates
    "tʃ": ["ʃ", "dʒ"], "dʒ": ["ʒ", "tʃ"],
    # Nasals
    "m": ["n", "p", "b"], "n": ["m", "ŋ", "ɾ"], "ŋ": ["n", "k", "g"],
    # Liquids/Glides
    "ɹ": ["l", "w"], "l": ["ɹ", "ɫ"], "ɫ": ["o", "ʊ"],
    "j": ["dʒ"], "w": ["v"],
    # Vowels
    "i": ["ɪ", "iː"], "ɪ": ["i", "e"],
    "e": ["ɛ", "ɪ"], "ɛ": ["æ", "e"],
    "æ": ["ɑ", "ɛ"], "ɑ": ["ɔ", "ʌ"],
    "ɔ": ["ɑ", "o"], "o": ["ɔ", "ʊ"],
    "u": ["ʊ", "o"], "ʊ": ["u", "o"],
    "ʌ": ["ə", "ɜ"], "ə": ["ʌ", "ɜ", "ɚ"],
    "ɜ": ["ə", "ɚ"], "ɚ": ["ɜ", "ə"],
    # Diphthongs
    "aɪ": ["ɑ", "e"], "aʊ": ["æ", "ʌ"],
    "ɔɪ": ["ɔ", "ɪ"], "oʊ": ["o", "ʊ"],
    # Special cases
    "ɾ": ["t", "d"], "n̩": ["n", "ən"]
}

DEFAULT_CACHE_DIR = "/cache_dir"
MODEL_PATH = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"


def create_confusion_id_map(tokenizer: Wav2Vec2CTCTokenizer) -> Dict[int, List[int]]:
    """Convert phoneme symbols to model token IDs with validation."""
    confusion_map = {}
    for phoneme, confusions in PHONEME_CONFUSION_MAP.items():
        try:
            phoneme_id = tokenizer._convert_token_to_id(phoneme)
            confusion_ids = [tokenizer._convert_token_to_id(c) for c in confusions]
            confusion_map[phoneme_id] = confusion_ids
        except KeyError as e:
            logger.warning(f"Skipping phoneme {phoneme}: {str(e)}")
    return confusion_map

def initialize_components() -> Tuple[Wav2Vec2Processor, Wav2Vec2CTCTokenizer, Wav2Vec2ForCTC]:
    """Initialize model components with proper caching and configuration."""
    processor = Wav2Vec2Processor.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    model = Wav2Vec2ForCTC.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    model.eval()
    return processor, tokenizer, model

#def convert_ipa_to_list(row):
#    """
#    Convert 'phonetic_transcription_ipa' from a string to a list of phonemes.
#    """
#    row['phonetic_transcription_ipa_list'] = row['phonetic_transcription_ipa'].split()
#    return row


##return only likeli
def ctc_loss(params, seq, blank=0):
    """
    CTC loss function.
    params - n x m matrix of n-D probability distributions(softmax output) over m frames.
    seq - sequence of phone id's for given example.
    Returns objective, alphas and betas.
    """
    seqLen = seq.shape[0] # Length of label sequence (# phones)
    numphones = params.shape[0] # Number of labels
    L = 2*seqLen + 1 # Length of label sequence with blanks
    T = params.shape[1] # Length of utterance (time)

    alphas = torch.zeros((L,T)).double()
    alpha_bar = torch.zeros(T).double()

    # Initialize alphas and forward pass 
    alphas[0,0] = params[blank,0]
    alphas[1,0] = params[seq[0],0]
    alpha_bar[0] = torch.sum(alphas[:,0])
    alphas[:,0] = alphas[:,0] /  alpha_bar[0]

    for t in range(1,T):
        start = max(0,L-2*(T-t)) 
        end = min(2*t+2,L)
        for s in range(start,L):
            l = int((s-1)/2)
            # blank
            if s%2 == 0:
                if s==0:
                    alphas[s,t] = alphas[s,t-1] * params[blank,t]
                else:
                    alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1]) * params[blank,t]
            # same label twice
            elif s == 1 or seq[l] == seq[l-1]:
                alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1]) * params[seq[l],t]
            else:
                alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1] + alphas[s-2,t-1]) \
                    * params[seq[l],t]
        alpha_bar[t] = torch.sum(alphas[:,t])
        alphas[:,t] = alphas[:,t] / alpha_bar[t]
    
    llForward = torch.log(alpha_bar).sum()   
	
    return -llForward


##make the deleted labels, returning both the original and deleted lables, the second) 
def make_deletion(labels, pos):
  
    return [labels, torch.cat((labels[:pos], labels[pos+1:]))]

def check_arbitrary(in_alphas, s, t, zero_pos=[]):
    if torch.count_nonzero(in_alphas[s, t]) > 1:
        if len(zero_pos) != 0:
            mask = torch.ones_like(in_alphas[s, t])
            for i in zero_pos:
                mask[i] = 0
            return sum(in_alphas[s, t][mask.bool()])
        else:
            return sum(in_alphas[s, t][:])
    else:
        return False

def get_alpha_bar(alphas, t, blank, pos):
    arbitrary_state = 2 * pos + 1
    alpha_mask = torch.ones(alphas.shape[2], dtype=torch.bool)
    alpha_mask[blank] = False
    return alphas[:arbitrary_state, t, 0].sum() + alphas[arbitrary_state + 1:, t, 0].sum() + alphas[arbitrary_state, t, alpha_mask].sum()

def ctc_loss_denom_4(params, seq, pos, blank=0, substitution_mapping=None):
    seqLen = seq.shape[0]  # Length of label sequence (# phones)
    L = 2 * seqLen + 1  # Length of label sequence with blanks
    T = params.shape[1]  # Length of utterance (time)
    P = params.shape[0]  # Number of tokens

    epsilon = 1e-40  # Small constant to prevent division by zero

    mask_ins = torch.eye(P)

    alphas = torch.zeros((L, T, P)).double()
    alpha_bar = torch.zeros(T)

    # Path tracker to log paths
    path_tracker = {}

    # Initialize alphasAX
    if pos == 0:
        alphas[0, 0, 0] = params[blank, 0]
        alphas[1, 0] = params[:, 0]
        alphas[1, 0, 0] = 0  # Can't stay at blank
    else:
        alphas[0, 0, 0] = params[blank, 0]
        alphas[1, 0, 0] = params[seq[0], 0]

    alpha_bar[0] = get_alpha_bar(alphas, 0, blank, pos)
    alpha_bar[0] = max(alpha_bar[0], epsilon)  # Ensure no division by zero
    alphas[:, 0, :] = alphas[:, 0, :] / alpha_bar[0]

    for t in range(1, T):
        start = max(0, L - 2 * (T - t))
        for s in range(start, L):
            l = int((s - 1) / 2)

            # Determine allowed tokens based on substitution mapping
            allowed_tokens = torch.zeros(params.shape[0], dtype=torch.bool)

            if substitution_mapping is None:
                substitution_mapping = {}

            current_token = seq[pos].item() if isinstance(seq[pos], torch.Tensor) else seq[pos]

            if current_token in substitution_mapping:
                allowed_tokens[substitution_mapping[current_token]] = True
            else:
                allowed_tokens[:] = True  # Allow all tokens if no substitution mapping exists

            if not allowed_tokens.any():
                print(f"Warning: No valid tokens allowed at time {t}, state {s}. Defaulting to all tokens.")
                allowed_tokens[:] = True  # Allow all tokens if logic fails

            if s not in path_tracker:
                path_tracker[s] = {}

            if s % 2 == 0:  # Blank state
                if s == 0:
                    alphas[s, t, 0] = alphas[s, t - 1, 0] * params[blank, t]
                else:
                    sum = check_arbitrary(alphas, s - 1, t - 1, [blank])
                    if sum:
                        alphas[s, t, 0] = (alphas[s, t - 1, 0] + sum) * params[blank, t]
                    else:
                        alphas[s, t, 0] = (alphas[s, t - 1, 0] + alphas[s - 1, t - 1, 0]) * params[blank, t]
            elif pos != l and pos != l - 1:
                if s == 1 or seq[l] == seq[l - 1]:
                    alphas[s, t, 0] = (alphas[s, t - 1, 0] + alphas[s - 1, t - 1, 0]) * params[seq[l], t]
                else:
                    alphas[s, t, 0] = (alphas[s, t - 1, 0] + alphas[s - 1, t - 1, 0] + alphas[s - 2, t - 1, 0]) * params[seq[l], t]
            elif pos == l - 1:
                sum = check_arbitrary(alphas, s - 2, t - 1, [blank, seq[l]])
                alphas[s, t, 0] = (alphas[s, t - 1, 0] + alphas[s - 1, t - 1, 0] + sum) * params[seq[l], t]
            else:  # Wildcard state
                if s == 1:
                    empty_prob = alphas[s - 1, t - 1, 0] * params[:, t]
                    empty_prob[~allowed_tokens] = 0  # Restrict to allowed tokens
                    empty_prob[blank] = 0  # Exclude blank contributions

                    path_tracker[s][t] = {"empty": empty_prob.nonzero(as_tuple=True)}

                    alphas[s, t, :] = (
                        (alphas[s, t - 1, :].view(1, -1) * params[:, t].view(-1, 1) * mask_ins).sum(-1)
                        + empty_prob
                    )
                else:
                    skip_prob = alphas[s - 2, t - 1, 0] * params[:, t]
                    skip_prob[~allowed_tokens] = 0  # Restrict to allowed tokens
                    skip_prob[seq[l - 1]] = 0  # Exclude paths involving the previous label
                    skip_prob[blank] = 0  # Exclude blank contributions

                    empty_prob = alphas[s - 1, t - 1, 0] * params[:, t]
                    empty_prob[~allowed_tokens] = 0  # Restrict to allowed tokens
                    empty_prob[blank] = 0  # Exclude blank contributions

                    scaled_transitions = (
                        (alphas[s, t - 1, :].view(1, -1) * params[:, t].view(-1, 1) * mask_ins).sum(-1)
                    )
                    scaled_transitions[~allowed_tokens] = 0  # Restrict to allowed tokens

                    path_tracker[s][t] = {
                        "empty": empty_prob.nonzero(as_tuple=True),
                        "skip": skip_prob.nonzero(as_tuple=True),
                        "scaled": scaled_transitions.nonzero(as_tuple=True),
                    }

                    alphas[s, t, :] = scaled_transitions + skip_prob + empty_prob

        alpha_bar[t] = get_alpha_bar(alphas, t, blank, pos)
        alpha_bar[t] = max(alpha_bar[t], epsilon)  # Ensure no division by zero
        alphas[:, t, :] = alphas[:, t, :] / alpha_bar[t]

    alpha_bar = torch.clamp(alpha_bar, min=epsilon)  # Prevent invalid values
    llForward = torch.log(alpha_bar).sum()
    return -llForward

def process_and_save_gop(dataset, processor, model, p_tokenizer, substitution_mapping, output_csv):
    """
    Process the dataset to calculate GOP scores and save the results in a CSV file.

    Args:
        dataset: The dataset to process.
        processor: Wav2Vec2Processor for input processing.
        model: Wav2Vec2ForCTC model.
        p_tokenizer: Tokenizer for phonetic transcriptions.
        substitution_mapping: Mapping for substitutions.
        output_csv: Path to save the resulting CSV.
    """
    results = []
    
    with torch.no_grad():
        for entry in tqdm(dataset, desc="Processing entries for GOP scores"):
            # Process audio and labels
            input_values = processor(entry["audio"]["array"], return_tensors="pt", sampling_rate=16000).input_values
            simulated_labels = torch.Tensor(p_tokenizer.convert_tokens_to_ids(entry["simulated_error_transcript"])).long()
            simulated_labels = simulated_labels.type(torch.int32)
            
            # Forward pass
            return_dict = model(input_values, labels=simulated_labels)
            logits = return_dict["logits"].squeeze(0)
            post_mat = logits.softmax(dim=-1).type(torch.float64)
            
            ll_self = ctc_loss(post_mat.transpose(0, 1), simulated_labels, blank=0)

            # Compute GOP scores
            pids = simulated_labels.tolist()
            for i, simulated_phone_id in enumerate(pids):
                label_list = make_deletion(simulated_labels, i)
                assert len(label_list) == 2
                ll_denom = ctc_loss_denom_4(post_mat.transpose(0, 1), label_list[0], i, blank=0, substitution_mapping=None)
                gop = -ll_self + ll_denom
                
                # Extract the corresponding phones
                simulated_phone = entry["simulated_error_transcript"][i]
                actual_phone = entry["transcript"][i]
                
                # Check for mispronunciation
                mispronounced = simulated_phone != actual_phone
                
                # Append the result
                results.append({
                    "uttid": entry["audio"]["path"],
                    "simulated phone": simulated_phone,
                    "actual phone": actual_phone,
                    "gop_score": gop.item(),
                    "mispronounced": mispronounced
                })
    
    # Save results to a CSV file
    with open(output_csv, mode="w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["uttid", "simulated phone", "actual phone", "gop_score", "mispronounced"])
        writer.writeheader()
        writer.writerows(results)

if __name__ == "__main__":
    dataset_path = "/data/mpc/simulated_error_mpc"
    prep_path = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"
    cache_dir = "/cache_dir"
    output_csv = "/mpc/paaf_ups.csv"

    # Initialize processor, tokenizer, and model
    processor, tokenizer, model = initialize_components()
    
    substitution_mapping = create_confusion_id_map(tokenizer)
    
    # Load dataset
    dataset = load_from_disk(dataset_path)
    #dataset = dataset.shuffle(seed=42).select(range(2))
    #dataset = dataset.map(convert_ipa_to_list)
    #dataset = dataset.rename_column("phonetic_transcription_ipa_list", "transcription")

    # Process dataset and save GOP scores
    process_and_save_gop(dataset, processor, model, tokenizer, substitution_mapping, output_csv)

    print("GOP scores saved to", output_csv)