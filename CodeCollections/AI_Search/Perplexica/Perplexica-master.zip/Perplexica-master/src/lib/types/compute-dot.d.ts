declare function computeDot(vectorA: number[], vectorB: number[]): number;

declare module 'compute-dot' {
  export default computeDot;
}
