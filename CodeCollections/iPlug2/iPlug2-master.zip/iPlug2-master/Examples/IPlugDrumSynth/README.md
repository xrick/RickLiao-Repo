# IPlugDrumSynth
A drum synthesiser example with multiple output buses.
