class BaseBar:
    pass
