var searchData=
[
  ['v_5fadd',['v_add',['../group__fxp__vec.html#ga6e2fbe78500df6b65eb2c978b773e32b',1,'vector.h']]],
  ['v_5fclip',['v_clip',['../group__fxp__vec.html#ga8e238c8336fd9b765f6127493083b9d7',1,'vector.h']]],
  ['v_5fefdiv_5fev',['v_efdiv_ev',['../group__fxp__vec.html#ga68321e2bcf603a625825a85cec5210e4',1,'vector.h']]],
  ['v_5ffmul',['v_fmul',['../group__fxp__vec.html#ga9c86c139cc22e8e96a60a9b384860ec9',1,'vector.h']]],
  ['v_5ffmul_5fdv',['v_fmul_dv',['../group__fxp__vec.html#gaed2427320fedb454a3573b6c5ef6240d',1,'vector.h']]],
  ['v_5fidiv',['v_idiv',['../group__fxp__vec.html#gac05c552d4ff00c5287a060bdd8480c71',1,'vector.h']]],
  ['v_5fimul',['v_imul',['../group__fxp__vec.html#ga633827cfcc6bf086a915bdbb4189f415',1,'vector.h']]],
  ['v_5fimul_5fev',['v_imul_ev',['../group__fxp__vec.html#ga25a337ac75db2612bb2ebaa47c121cce',1,'vector.h']]],
  ['v_5fmfmul_5fev',['v_mfmul_ev',['../group__fxp__vec.html#gacd6ef0265f8b683e7c7e8b098df4b451',1,'vector.h']]],
  ['v_5fmvmul_5fev',['v_mvmul_ev',['../group__fxp__vec.html#gaad218ef2ae36d35478c9845c14081188',1,'vector.h']]],
  ['v_5fsub',['v_sub',['../group__fxp__vec.html#gafd2991963fa040645ee607c82dbf255a',1,'vector.h']]],
  ['v_5fto_5fdv',['v_to_dv',['../group__fxp__vec.html#ga4de0e3898d779e9be5b63b8c20d2d240',1,'vector.h']]],
  ['v_5fto_5fev',['v_to_ev',['../group__fxp__vec.html#ga8ded939a96a68decf5eb8838b375fede',1,'vector.h']]]
];
