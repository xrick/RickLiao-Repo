#include <stdio.h>

void myFunction(void)
{
	printf("No parameters function.\n");
}

int main(void)
{
	myFunction();
}