# biaffine_dep

Biaffine dependency parser.

```{eval-rst}
.. currentmodule:: hanlp.components

.. autoclass:: hanlp.components.parsers.biaffine.biaffine_dep.BiaffineDependencyParser
	:members:

```
