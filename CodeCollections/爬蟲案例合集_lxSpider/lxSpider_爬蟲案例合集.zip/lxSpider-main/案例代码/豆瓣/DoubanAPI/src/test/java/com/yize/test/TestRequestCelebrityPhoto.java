package com.yize.test;

import com.yize.douban.module.CelebrityPhoto;
import org.junit.Test;

public class TestRequestCelebrityPhoto {
    @Test
    public void test(){
//        CelebrityPhoto celebrityPhoto=new CelebrityPhoto();
//        String response=celebrityPhoto.requestCelebrityMovie("27260217","0");
//        System.out.println(response);
    }
}
