    {{identifier}}_layer = new pico_cnn::naive::Clip("{{name}}", 0, pico_cnn::op_type::Clip, {{min}}, {{max}});
