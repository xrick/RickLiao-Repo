    {{identifier}}_layer = new pico_cnn::naive::ReLU("{{name}}", 0, pico_cnn::op_type::ReLU);
