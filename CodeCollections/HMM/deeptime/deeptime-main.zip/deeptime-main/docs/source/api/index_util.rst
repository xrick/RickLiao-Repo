.. _ref-util:

deeptime.util
=============
The *util* package contains various utilities used throughout the library.

.. automodule:: deeptime.util

.. toctree::
   :maxdepth: 1
