#pragma once

// OPENGL
#include <GL/glew.h>

// JUCE
#include "JuceHeader.h"
