#include <stdio.h>

int main(void)
{
	const char *str = "This string can not be modified!";
	printf("The value is: %s\n", str);
}