#pragma once

NS_HWM_BEGIN

wxPanel * CreateVirtualKeyboard(wxWindow *parent);

NS_HWM_END
