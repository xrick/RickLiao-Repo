# multi_criteria

Transformer based Multi-Criteria Word tokenizer.

```{eval-rst}
.. currentmodule:: hanlp.components.tokenizers.multi_criteria_cws_transformer

.. autoclass:: hanlp.components.tokenizers.multi_criteria_cws_transformer.MultiCriteriaTransformerTaggingTokenizer
	:members:

```
