#include <stdio.h>

int main(void)
{
	char c;
	c = 'A';
	int x;
	x = 123;
	float f;
	f = 123.456f;
	printf("Char: %c int: %d float: %.3f", c, x, f);
}