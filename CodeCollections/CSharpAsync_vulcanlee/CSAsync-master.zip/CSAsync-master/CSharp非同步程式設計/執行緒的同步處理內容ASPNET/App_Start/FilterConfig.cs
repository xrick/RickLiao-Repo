﻿using System.Web;
using System.Web.Mvc;

namespace 執行緒的同步處理內容ASPNET
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
