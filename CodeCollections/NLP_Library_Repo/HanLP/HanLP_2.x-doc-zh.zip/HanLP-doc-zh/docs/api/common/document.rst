.. _api/document:

document
====================

.. currentmodule:: hanlp_common

.. autoclass:: hanlp_common.document.Document
	:members:
