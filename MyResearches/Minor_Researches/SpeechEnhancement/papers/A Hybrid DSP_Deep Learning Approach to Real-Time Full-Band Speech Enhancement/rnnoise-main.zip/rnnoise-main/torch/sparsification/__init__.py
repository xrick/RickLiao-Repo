from .gru_sparsifier import GRUSparsifier
from .common import sparsify_matrix, calculate_gru_flops_per_step