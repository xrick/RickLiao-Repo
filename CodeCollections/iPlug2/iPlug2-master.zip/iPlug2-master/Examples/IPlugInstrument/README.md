# IPlugInstrument
A basic MPE capable synthesier plug-in with IGraphics GUI
