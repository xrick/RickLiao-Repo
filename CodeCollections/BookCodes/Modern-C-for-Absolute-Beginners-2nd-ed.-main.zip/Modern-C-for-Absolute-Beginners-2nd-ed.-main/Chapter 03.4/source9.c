#include <stdio.h>

int main(void)
{
	long long x;
	x = 123456789ll;
	printf("The value of a long long integer is: %lld", x);
}