#include <stdio.h>

int main(void)
{
	int arr[5] = {10, 20, 30, 40, 50};
	printf("Accessing the existent array element...\n");
	printf("The existent array element is: %d\n", arr[4]);
}