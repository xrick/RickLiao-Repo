#include <stdio.h>

#define MAX 100

int main(void)
{
	int x = MAX;
	printf("The value of x is: %d\n", x);
}