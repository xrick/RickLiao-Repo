const example = require('./example');

module.exports = {
  example
};
