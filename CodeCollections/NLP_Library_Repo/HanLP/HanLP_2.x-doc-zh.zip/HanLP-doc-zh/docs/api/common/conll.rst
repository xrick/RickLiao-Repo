.. _api/conll:

conll
====================


.. autoclass:: hanlp_common.conll.CoNLLWord
	:members:

.. autoclass:: hanlp_common.conll.CoNLLUWord
	:members:

.. autoclass:: hanlp_common.conll.CoNLLSentence
	:members: