#include <stdio.h>

int main(void)
{
	printf("Enter a single character: ");
	char mychar;
	scanf("%c", &mychar);
	printf("You entered: %c\n", mychar);
}