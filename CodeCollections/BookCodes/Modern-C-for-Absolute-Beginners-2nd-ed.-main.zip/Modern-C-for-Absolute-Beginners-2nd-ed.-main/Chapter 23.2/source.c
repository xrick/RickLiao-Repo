#include <stdio.h>

#define MAX 100

int main(void)
{
	printf("Symbolic identifier MAX is: %d\n", MAX);
}