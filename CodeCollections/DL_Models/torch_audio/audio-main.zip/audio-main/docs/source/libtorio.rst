libtorio
========

.. warning::
   TorchAudio's C++ API is a prototype feature.
   API/ABI backward compatibility is not guaranteed.

.. toctree::
   libtorio.stream_reader
   libtorio.stream_writer
