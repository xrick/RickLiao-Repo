# glove

```{eval-rst}

.. automodule:: hanlp.pretrained.glove
    :members:

```