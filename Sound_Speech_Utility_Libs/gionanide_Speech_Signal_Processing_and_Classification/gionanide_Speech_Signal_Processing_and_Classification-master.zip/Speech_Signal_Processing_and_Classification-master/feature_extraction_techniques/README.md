Feature extraction techniques implemented in Python

MFCC  
LPC  
PLP  
MGCA
