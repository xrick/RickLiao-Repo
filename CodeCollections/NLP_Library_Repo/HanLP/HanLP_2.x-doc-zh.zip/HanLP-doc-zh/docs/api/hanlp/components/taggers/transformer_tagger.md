# transformer_tagger

Transformer based tagger.

```{eval-rst}
.. currentmodule:: hanlp.components

.. autoclass:: hanlp.components.taggers.transformers.transformer_tagger.TransformerTagger
	:members:

```
