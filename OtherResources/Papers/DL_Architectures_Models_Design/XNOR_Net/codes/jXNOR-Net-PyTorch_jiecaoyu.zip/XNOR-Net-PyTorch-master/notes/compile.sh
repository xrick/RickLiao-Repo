pdflatex notes.tex
