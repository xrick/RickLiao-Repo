# Misc

## Model View Controller

- Why
- Example
- Talk

## File IO

- Record/Playback
- Sampler

## Network IO

- Open Sound Control
  - Arduino

## OpenGL

- Text for 3 examples
- How to use GLEW
  - If not, how to get function pointers using `openglcontext.extensions`.
