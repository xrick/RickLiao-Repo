int main(void)
{
	char mychar;
	mychar = 97;
}