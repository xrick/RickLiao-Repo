This folder contains some artifacts auto generated from continuous build workflow. The
intention is to monitor these artifacts, such as size data, to measure and
detect any performance variation. The long term goal is to monitor these
performance data points through some dashboard based on these artifacts.
