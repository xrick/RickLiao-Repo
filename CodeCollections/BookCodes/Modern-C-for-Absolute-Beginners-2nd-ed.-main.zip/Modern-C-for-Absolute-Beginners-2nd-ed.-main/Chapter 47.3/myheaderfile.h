#ifndef MYHEADERFILE_H
#define MYHEADERFILE_H

// shared constants and variables declarations
extern const int MY_MAX;
extern const char *MY_MESSAGE;
extern const double MY_PI;

// shared variables
extern int mysharedint;
extern double myshareddouble;

#endif