---
title: Panel Tweak Matplotlib by Chatting with Mistral
emoji: 💬
colorFrom: gray
colorTo: blue
sdk: docker
pinned: false
duplicated_from: Panel-Org/panel-template
license: bsd-3-clause
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
