# -*- coding: utf-8 -*-


encode_mmid = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1IjozNzA1ODEzNiwibGV2ZWwiOjAsInQiOiJjdHQifQ.Wbi1oFVVxDNES0V7p50RZdbD8KjfrHLrHuOLaxRegaI"

s2 = f'https://maimai.cn/contact/detail/{encode_mmid}?fr=&from=webview%23%2Fweb%2Ffeed_detail'

