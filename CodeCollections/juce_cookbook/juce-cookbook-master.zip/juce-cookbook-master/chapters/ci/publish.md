# Publish

- GitHub releases
- zip
- installer/package

## Deploy

- docs
- app/plug-in
