#include <stdio.h>

int myFunction(int, int);

int main(void)
{
	printf("Function declared.\n");
}