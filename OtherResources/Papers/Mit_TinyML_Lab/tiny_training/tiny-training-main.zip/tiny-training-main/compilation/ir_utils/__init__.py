from .general_func import ir_scan_op, check_call_dtype, check_call_shape, ChangeName
from .ir_visualize import MyVisistor, VisualizeIR
