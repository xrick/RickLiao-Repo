#include <stdio.h>

int main(void)
{
	int x = 9;
	int y = 2;
	double z = (double)x / y;
	printf("The result is: %.3f\n", z);
}