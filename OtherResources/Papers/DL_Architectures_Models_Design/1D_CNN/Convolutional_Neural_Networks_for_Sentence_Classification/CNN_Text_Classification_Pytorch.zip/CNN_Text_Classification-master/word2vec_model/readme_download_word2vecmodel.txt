You can download the "slim" Google News embeddings from this Github repository
(using `git lfs` for downloading large files) from: 
https://github.com/eyaler/word2vec-slim

You can download the complete embeddings directly from Google's archive, here: 
https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit

You are also free to use a different pre-trained model 
or train an embedding layer from scratch!
