# Tokenization

## Chinese
```{toctree}
ctb
msr
```