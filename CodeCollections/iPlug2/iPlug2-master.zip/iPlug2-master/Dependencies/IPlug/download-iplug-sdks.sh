#!/usr/bin/env bash

./download-vst3-sdk.sh
./download-clap-sdks.sh
./download-wam-sdk.sh