var searchData=
[
  ['quaternion_2eh',['quaternion.h',['../inline_2quaternion_8h.html',1,'(Global Namespace)'],['../quaternion_8h.html',1,'(Global Namespace)']]],
  ['quaternion_5ftypes_2eh',['quaternion_types.h',['../quaternion__types_8h.html',1,'']]]
];
