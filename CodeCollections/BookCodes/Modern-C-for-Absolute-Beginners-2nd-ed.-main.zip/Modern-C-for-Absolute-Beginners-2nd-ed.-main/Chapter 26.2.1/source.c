#include <stdio.h>

int main(void)
{
	int x = 123; // x is declared here
	printf("Variable x has automatic storage and a value of: %d\n", x);
} // x goes out of scope here