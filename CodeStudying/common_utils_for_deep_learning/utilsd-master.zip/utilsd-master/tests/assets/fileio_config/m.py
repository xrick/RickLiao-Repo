_base_ = ['./l1.py', './l2.yaml', './l3.json', 'a.py']
item3 = False
item4 = 'test'
