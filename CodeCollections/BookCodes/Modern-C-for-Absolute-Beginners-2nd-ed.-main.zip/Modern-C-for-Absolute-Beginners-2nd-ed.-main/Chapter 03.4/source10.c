#include <stdio.h>

int main(void)
{
	unsigned long long x;
	x = 123456789llu;
	printf("The value of an unsigned long long integer is: %llu", x);
}