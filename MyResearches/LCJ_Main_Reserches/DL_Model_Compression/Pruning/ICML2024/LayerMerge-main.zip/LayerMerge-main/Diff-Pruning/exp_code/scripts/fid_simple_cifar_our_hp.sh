python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.01_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.001_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0001_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256

python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.01_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.001_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0001_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256

python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.002_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0002_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.00002_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256

python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.002_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0002_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.00002_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256

python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.004_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0004_beta0.9/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256

python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.004_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256
python -B fid_score.py run/sample_diffprune/ls-CosineAnnealingLR_cifar10_ours_T=0.05_lr0.0004_beta0.99/image_samples/images/0 run/fid_stats_cifar10.npz --device cuda:0 --batch-size 256