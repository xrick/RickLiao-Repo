#include "myheaderfile.h"
#include <stdio.h>

int main(void)
{
	printf("Calling a function defined in the source2.c file:\n");
	myfunction();
}