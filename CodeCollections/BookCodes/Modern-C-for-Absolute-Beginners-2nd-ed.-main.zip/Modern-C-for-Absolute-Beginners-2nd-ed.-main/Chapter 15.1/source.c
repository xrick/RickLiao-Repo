#include <stdio.h>

struct MyStruct
{
	char c;
	int x;
	double d;
};

int main(void)
{
	printf("Declared a structure of type: struct MyStruct.\n");
}