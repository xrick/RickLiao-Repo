# torch_component

```{eval-rst}
.. currentmodule:: hanlp.common.torch_component

.. autoclass:: hanlp.common.torch_component.TorchComponent
	:members:

```
