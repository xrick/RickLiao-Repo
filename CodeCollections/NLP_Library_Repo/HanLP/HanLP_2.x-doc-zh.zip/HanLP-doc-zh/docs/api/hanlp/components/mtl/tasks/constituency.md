# con

Constituency parsing.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.constituency.CRFConstituencyParsing
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
