#include <stdio.h>

int main(void)
{
    bool condition = true;
    if (condition)
    {
        printf("The condition is true.\n");
    }
    else
    {
        printf("The condition is false.\n");
    }
}