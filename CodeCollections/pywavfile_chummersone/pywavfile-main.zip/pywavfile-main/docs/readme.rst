.. include:: ../README.rst
   :start-after: github-only-above-here
