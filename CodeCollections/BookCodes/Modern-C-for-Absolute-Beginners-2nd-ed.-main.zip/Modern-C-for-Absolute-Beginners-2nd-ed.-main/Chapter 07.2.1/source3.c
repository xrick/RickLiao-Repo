#include <stdio.h>

int main(void)
{
	int x = 123;
	int y = 456;
	if (x < 150 || y > 150)
	{
		printf("The condition is true.\n");
	}
}