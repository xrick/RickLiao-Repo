var searchData=
[
  ['ef_5fadd',['ef_add',['../group__fxp__arith.html#ga7089a256fcead175c82257c1ff384693',1,'fixed_point.h']]],
  ['ef_5ff_5fadd',['ef_f_add',['../group__fxp__arith.html#ga57fd8f85b01bab89eb301eff878fb72b',1,'fixed_point.h']]],
  ['ef_5fidiv',['ef_idiv',['../group__fxp__arith.html#gae1dc2044a2b0624ae50e153edc087163',1,'fixed_point.h']]],
  ['ef_5fimul',['ef_imul',['../group__fxp__arith.html#ga6844b20b6876ba7dfa4eebbff95fd083',1,'fixed_point.h']]],
  ['ef_5fneg',['ef_neg',['../group__fxp__arith.html#gace150654550b6c4bcc077f0e0986f143',1,'fixed_point.h']]],
  ['ef_5fsub',['ef_sub',['../group__fxp__arith.html#ga4c9cbaaddaaa506a12db8acfbd8f24c4',1,'fixed_point.h']]],
  ['ef_5fto_5ff',['ef_to_f',['../group__fxp__arith.html#ga1fa59a8ad97e0be55cecb8ae720ca8c5',1,'fixed_point.h']]],
  ['ev_5fadd',['ev_add',['../group__fxp__vec.html#ga54fc27230b62e4f143ed99d11af89cc7',1,'vector.h']]],
  ['ev_5fidiv',['ev_idiv',['../group__fxp__vec.html#ga1b23b4b4d35cd7b48a4a89b7a4e3fc0c',1,'vector.h']]],
  ['ev_5fimul',['ev_imul',['../group__fxp__vec.html#ga53dd2804c46f5f6e794b4ddb81d17efa',1,'vector.h']]],
  ['ev_5fsub',['ev_sub',['../group__fxp__vec.html#ga4746c84959f558a2f520caa5bf9d5526',1,'vector.h']]],
  ['ev_5fto_5fv',['ev_to_v',['../group__fxp__vec.html#ga835775ff371ce6c65a6da1b568f51706',1,'vector.h']]]
];
