    pico_cnn::naive::ReLU *{{identifier}}_layer;
