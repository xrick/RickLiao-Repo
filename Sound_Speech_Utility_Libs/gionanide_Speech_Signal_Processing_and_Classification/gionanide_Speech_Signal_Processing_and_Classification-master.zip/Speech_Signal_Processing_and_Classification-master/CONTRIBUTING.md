# Issues for contribution

   - Feature extraction techniques from skratch LPC, MFCC, PLP for comparing the results with the already made ones.
  
   -  Varitional Autoencoders (VAE) for finding a lower representation of the extracted features. Furthermore we can produce artificial samples using VAEs, with this procedure we can overcome the obstacle that the imbalance dataset causes.
