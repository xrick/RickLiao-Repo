这里给出unidbg的调用代码。

趣头条sign逆向教程： http://t.csdn.cn/X6Lun