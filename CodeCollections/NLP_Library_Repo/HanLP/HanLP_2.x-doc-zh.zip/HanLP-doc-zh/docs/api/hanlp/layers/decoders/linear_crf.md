# linear_crf


```{eval-rst}

.. autoclass:: hanlp.components.mtl.tasks.pos.LinearCRFDecoder
	:members:

```
