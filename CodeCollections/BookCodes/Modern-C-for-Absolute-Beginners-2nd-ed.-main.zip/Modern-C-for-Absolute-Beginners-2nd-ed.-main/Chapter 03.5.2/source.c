int main(void)
{
	double d;
	d = 123.456;
}