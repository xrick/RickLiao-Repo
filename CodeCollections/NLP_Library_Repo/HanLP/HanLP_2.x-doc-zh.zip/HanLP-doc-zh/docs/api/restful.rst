.. _api/hanlp_restful:

hanlp_restful
====================

.. currentmodule:: hanlp_restful

.. autoclass:: HanLPClient
	:members:
	:special-members:
	:exclude-members: __init__, __repr__, __weakref__