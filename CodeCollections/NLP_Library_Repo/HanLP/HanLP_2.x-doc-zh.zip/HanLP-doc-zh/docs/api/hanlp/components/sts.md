# sts

```{eval-rst}
.. currentmodule:: hanlp.components.sts

.. autoclass:: hanlp.components.sts.transformer_sts.TransformerSemanticTextualSimilarity
	:members:

```

