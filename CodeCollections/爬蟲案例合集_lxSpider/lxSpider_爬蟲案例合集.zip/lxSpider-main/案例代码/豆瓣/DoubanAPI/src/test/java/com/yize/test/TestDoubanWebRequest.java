package com.yize.test;
import com.yize.douban.base.DoubanWebRequest;
import org.junit.Test;
import java.util.HashMap;

public class TestDoubanWebRequest {
    @Test
    public void testWebRequest(){
//        HashMap<String,String> paramsMap=new HashMap<>();
//        paramsMap.put("count","0");
//        paramsMap.put("start","20");
//        paramsMap.put("sortby","hot");
//        paramsMap.put("os_rom","android");
//        String response=DoubanWebRequest.downloadWebSiteUseGet("https://frodo.douban.com/api/v2/tv/coming_soon",paramsMap);
//        System.out.println(response);
    }
}
