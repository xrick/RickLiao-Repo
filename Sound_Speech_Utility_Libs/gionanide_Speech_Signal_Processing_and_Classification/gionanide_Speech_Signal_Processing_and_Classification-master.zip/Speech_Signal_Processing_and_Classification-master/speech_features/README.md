EXAMPLE speech features extracted with various techniques.

MFCC (Mel Frequency Cepstral Coefficient)  
  
PLP (Perceptual Linear Prediction)  
  
  - with RASTA filtering  
  - and without  
    
LPC (Liner Predictive Coding)  
  
MGCA(Mel Generalized Cepstrum Analysis) 
