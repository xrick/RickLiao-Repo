#include <stdio.h>

int main(void)
{
	char c = 'A';
	int x;
	x = (int)c;
	printf("The result is: %d\n", x);
} 