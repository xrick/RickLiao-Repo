---

### windows采集系统

项目链接： [微信采集系统项目文档](https://github.com/lixi5338619/weixin-spider)

项目简介： 微信公众号文章的阅读数、在看数、评论数、评论列表，还有微信公众号的账号基本信息。


---

PC微信Hook监听

https://mp.weixin.qq.com/s/heZdISUcdU6RLNMdk-vsFg

---

### 通过公众平台采集文章

项目链接： [通过微信公众平台获取公众号文章](https://blog.csdn.net/weixin_43582101/article/details/103682490)

项目简介： 这个方法可能并没有其他的优秀，但是操作简单，很容易理解。

---

### 网页版监听

项目链接： [通过网页版获取公众号文章](https://blog.csdn.net/weixin_43582101/article/details/100306681)

项目简介： 之前可以，现在很多账号都不行了

---

### xposed-hook

检测很严，差点封号！

---

### 第三方平台

清博数据、新榜等