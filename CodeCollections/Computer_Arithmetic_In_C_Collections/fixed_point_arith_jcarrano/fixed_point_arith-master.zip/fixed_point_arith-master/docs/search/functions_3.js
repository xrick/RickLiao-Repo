var searchData=
[
  ['q_5fadd',['q_add',['../group__fxp__quat.html#ga36d7ba88ae22bad75a995af6adc34a08',1,'quaternion.h']]],
  ['q_5fconj',['q_conj',['../group__fxp__quat.html#gaeb5839250a45a7a39b2ae20d08cde618',1,'quaternion.h']]],
  ['q_5ferror',['q_error',['../group__fxp__q__errors.html#ga9c43cbaafe54000b51ca2cfd74c5c794',1,'quaternion.h']]],
  ['q_5ferror2',['q_error2',['../group__fxp__q__errors.html#gaace5dfba648c2d835e6c72b70b6cfb0a',1,'quaternion.h']]],
  ['q_5fmul',['q_mul',['../group__fxp__quat.html#gabe5c085aca8f8a569b152b407fd0af1d',1,'quaternion.h']]],
  ['q_5fmul_5fdq',['q_mul_dq',['../group__fxp__quat.html#ga505363132dc8dea2148543b712413572',1,'quaternion.h']]],
  ['q_5fmul_5fs_5fdq',['q_mul_s_dq',['../group__fxp__quat.html#ga0342229bd75211e25f2a6d533c364248',1,'quaternion.h']]],
  ['q_5frot',['q_rot',['../group__fxp__quat.html#ga5f4cd76b363bf7edc76314ba9e022247',1,'quaternion.h']]],
  ['q_5fscale',['q_scale',['../group__fxp__quat.html#gade2e08872684d4679d4db04c5f8c557d',1,'quaternion.h']]],
  ['q_5fscale_5fdq',['q_scale_dq',['../group__fxp__quat.html#gaba75cdf751cedb8c2b9aabeb2490b517',1,'quaternion.h']]],
  ['q_5fudecompose',['q_udecompose',['../group__fxp__quat.html#gae0679c6883575f5cf16513ced1160069',1,'quaternion.h']]],
  ['q_5fxnormerror',['q_xnormerror',['../group__fxp__quat.html#gabdde83c8c8ccf17bee58c9a628a718b6',1,'quaternion.h']]],
  ['q_5fxrenorm',['q_xrenorm',['../group__fxp__quat.html#ga003eb4e420c1de841be443094f6acc8d',1,'quaternion.h']]]
];
