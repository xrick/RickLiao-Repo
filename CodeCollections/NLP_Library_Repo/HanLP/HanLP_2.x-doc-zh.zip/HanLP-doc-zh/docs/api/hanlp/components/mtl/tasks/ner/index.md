# ner

Named Entity Recognition.

```{toctree}
tag_ner
biaffine_ner
```

