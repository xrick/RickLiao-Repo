# hanlp_demo_py
HanLP demo java => demo python  

 环境:  
 ubuntu 16.04  
 python 3.5.2  

<pre>
有全部测试过
测试：
python3 demo_at_first_sight.py
</pre>

注意： 部分涉及分词测速等由于机器的不同，会显示不同的数值而提示测试不通过。
