Software License
================

.. literalinclude:: ../../LICENSE.txt
   :language: none

Third party notices
-------------------

.. literalinclude:: ../../ThirdPartyNotices.txt
   :language: none
