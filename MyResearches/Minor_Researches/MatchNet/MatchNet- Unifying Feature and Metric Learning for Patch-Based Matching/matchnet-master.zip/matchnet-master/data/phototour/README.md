Here we put the original patch data. The following commands can be used to
download and unzip the data, assuming the current directory is where this file
is.

    curl -O http://www.cs.ubc.ca/~mbrown/patchdata/liberty.zip
    unzip -q -d liberty liberty.zip
    rm liberty.zip

    curl -O http://www.cs.ubc.ca/~mbrown/patchdata/notredame.zip
    unzip -q -d notredame notredame.zip
    rm notredame.zip

    curl -O http://www.cs.ubc.ca/~mbrown/patchdata/yosemite.zip
    unzip -q -d yosemite yosemite.zip
    rm yosemite.zip


