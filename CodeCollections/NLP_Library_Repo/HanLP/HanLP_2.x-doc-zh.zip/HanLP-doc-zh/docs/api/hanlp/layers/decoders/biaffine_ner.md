# biaffine_ner


```{eval-rst}

.. autoclass:: hanlp.components.ner.biaffine_ner.biaffine_ner_model.BiaffineNamedEntityRecognitionDecoder
	:members:

```
