#include <stdio.h>

void noparamsfn()
{
      printf("This function does not accept parameters.\n");
}

int main(void)
{
      noparamsfn();
}