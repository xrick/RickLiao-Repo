# dep

Dependency parsing.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.dep.BiaffineDependencyParsing
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
