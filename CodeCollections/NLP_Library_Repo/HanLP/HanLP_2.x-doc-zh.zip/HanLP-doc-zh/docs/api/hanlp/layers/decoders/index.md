# decoders

```{toctree}
linear_crf
biaffine_ner
```

