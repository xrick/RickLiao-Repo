var searchData=
[
  ['dfrac_5fbase',['dfrac_base',['../group__fxp__class.html#ga2be24a67cbbf8582dad622ae34d49350',1,'types.h']]]
];
