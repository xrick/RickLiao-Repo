var searchData=
[
  ['quaternion_20errors',['Quaternion Errors',['../group__fxp__q__errors.html',1,'']]],
  ['quaternions',['Quaternions',['../group__fxp__quat.html',1,'']]]
];
