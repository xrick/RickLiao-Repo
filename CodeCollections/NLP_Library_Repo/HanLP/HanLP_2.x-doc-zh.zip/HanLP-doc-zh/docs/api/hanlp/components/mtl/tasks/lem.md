# lem

Lemmatization.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.lem.TransformerLemmatization
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
