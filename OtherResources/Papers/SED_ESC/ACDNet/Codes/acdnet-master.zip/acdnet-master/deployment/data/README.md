# Data

This folder is reserved for use to store generated data sets in a raw flat buffer format.