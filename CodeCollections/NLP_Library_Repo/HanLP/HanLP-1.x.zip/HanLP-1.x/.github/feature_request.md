---
name: 🚀新功能请愿
about: 建议增加一个新功能
title: ''
labels: feature request
assignees: hankcs

---

<!--
提问请上论坛，不要发这里！
提问请上论坛，不要发这里！
提问请上论坛，不要发这里！

以下必填，否则直接关闭。
-->

**Describe the feature and the current behavior/state.**

**Will this change the current api? How?**

**Who will benefit with this feature?**

**Are you willing to contribute it (Yes/No):**

**System information**
- OS Platform and Distribution (e.g., Linux Ubuntu 16.04):
- Python/Java version:
- HanLP version:

**Any other info**

* [ ] I've carefully completed this form.
<!-- 发表前先搜索，此处一定要勾选！ -->
<!-- 发表前先搜索，此处一定要勾选！ -->
<!-- 发表前先搜索，此处一定要勾选！ -->