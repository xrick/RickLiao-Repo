ALTER TABLE questions
ADD COLUMN account_id serial;