    pico_cnn::naive::Convolution *{{identifier}}_layer;
