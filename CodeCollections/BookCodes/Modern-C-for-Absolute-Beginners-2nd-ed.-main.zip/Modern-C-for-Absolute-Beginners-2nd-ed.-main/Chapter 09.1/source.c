int main(void)
{
	int myarr[5];
}