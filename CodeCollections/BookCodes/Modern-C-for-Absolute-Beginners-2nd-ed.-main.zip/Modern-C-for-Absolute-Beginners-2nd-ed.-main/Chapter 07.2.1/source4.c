#include <stdio.h>

int main(void)
{
	int x = 0;
	if (!x)
	{
		printf("The condition is true.\n");
	}
}