ALTER TABLE answers
ADD COLUMN account_id serial;
