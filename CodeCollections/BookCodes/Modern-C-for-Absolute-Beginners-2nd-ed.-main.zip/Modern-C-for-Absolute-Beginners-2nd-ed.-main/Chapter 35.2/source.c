#include <stdio.h>

int main(void)
{
    int x = 0b1010;
    printf("The value of the integer variable x is: %d\n", x); 
}