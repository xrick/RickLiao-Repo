#include <stdio.h>

typedef int MyInt;

int main(void)
{
	MyInt x = 123;
	printf("The value is: %d\n", x);
}