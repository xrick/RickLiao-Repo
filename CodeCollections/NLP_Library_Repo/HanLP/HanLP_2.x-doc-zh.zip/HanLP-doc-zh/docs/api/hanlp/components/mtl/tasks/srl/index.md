# srl

Semantic Role Labeling.

```{toctree}
bio_srl
rank_srl
```

