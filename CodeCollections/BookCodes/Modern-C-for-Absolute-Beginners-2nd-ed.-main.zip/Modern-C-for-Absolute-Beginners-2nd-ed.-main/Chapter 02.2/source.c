int main(void)
{
	/* This is a comment in C */
}