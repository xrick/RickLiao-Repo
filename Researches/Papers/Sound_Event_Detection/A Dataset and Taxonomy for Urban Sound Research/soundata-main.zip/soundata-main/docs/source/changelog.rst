.. _changelog:

#########
Changelog
#########

The list of all changes in Soundata releases can be found `here <https://github.com/soundata/soundata/releases>`_.