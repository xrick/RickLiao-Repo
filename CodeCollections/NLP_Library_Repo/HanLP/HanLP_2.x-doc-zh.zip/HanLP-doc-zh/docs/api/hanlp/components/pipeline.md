# pipeline

```{eval-rst}
.. currentmodule:: hanlp.components.pipeline

.. autoclass:: hanlp.components.pipeline.Pipe
	:members:
	
.. autoclass:: hanlp.components.pipeline.Pipeline
	:members:

```

