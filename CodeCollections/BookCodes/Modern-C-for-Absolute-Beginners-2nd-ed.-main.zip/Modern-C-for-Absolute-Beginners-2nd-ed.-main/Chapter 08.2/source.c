#include <stdio.h>

int main(void)
{
	int x = 9;
	int y = 2;
	int z = x / y;
	printf("The result is: %d\n", z);
}