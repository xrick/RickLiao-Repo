int main(void)
{
	float myfloat;
	myfloat = 123.456f;
}