# Mean File Format
## General Structure
```
MAGIC_NUMBER
MEAN_0
MEAN_1
MEAN_2
``` 

# Example
```
FD
0x1.a00828p+6
0x1.d2ad8ap+6
0x1.eab34ep+6
```
