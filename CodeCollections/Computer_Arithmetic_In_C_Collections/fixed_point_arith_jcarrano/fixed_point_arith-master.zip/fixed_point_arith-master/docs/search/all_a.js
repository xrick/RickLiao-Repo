var searchData=
[
  ['r',['r',['../group__fxp__quat.html#a8dd396935bdb78d812da4215ed15f45b',1,'quat::r()'],['../group__fxp__quat.html#a8c1271b46ad425f0ecf0ddaddb8e896c',1,'dquat::r()']]]
];
