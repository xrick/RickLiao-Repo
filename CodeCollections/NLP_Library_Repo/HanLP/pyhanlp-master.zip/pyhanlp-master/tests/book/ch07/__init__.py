# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-07-04 17:26
# 《自然语言处理入门》第 7 章 词性标注
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
