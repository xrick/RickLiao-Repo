#include <stdio.h>

int main(void)
{
	char c = 'a';
	int x = 123;
	float f = 123.456f;
	double d = 789.123;
	printf("The values are: %c, %d, %.3f, %.3f\n", c, x, f, d);
}