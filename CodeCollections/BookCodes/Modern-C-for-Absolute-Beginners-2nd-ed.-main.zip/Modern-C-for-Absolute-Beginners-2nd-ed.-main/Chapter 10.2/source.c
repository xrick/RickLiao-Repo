int main(void)
{
	int x = 123;
	int *p = &x;
}