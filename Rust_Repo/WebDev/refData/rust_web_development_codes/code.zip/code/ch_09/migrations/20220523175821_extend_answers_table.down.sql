ALTER TABLE answers
DROP COLUMN account_id;
