_base_ = './base.py'
item2 = {'b': 0, '_delete_': True}
