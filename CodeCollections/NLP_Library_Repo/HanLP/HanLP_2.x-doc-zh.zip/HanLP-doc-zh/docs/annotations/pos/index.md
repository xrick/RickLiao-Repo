# Part-of-Speech Tagging

## Chinese
```{toctree}
ctb
pku
863
```

## Japanese
```{toctree}
npcmj
```

## Multilingual

```{toctree}
ud
```



