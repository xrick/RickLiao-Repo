# tokenizer


```{eval-rst}

.. autoclass:: hanlp.transform.transformer_tokenizer.TransformerSequenceTokenizer
	:members:

```
