.. py:module:: torio.utils

torio.utils
===========

``torio.utils`` module contains utility functions to query and configure the global state of third party libraries.

.. currentmodule:: torio.utils

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: autosummary/utils.rst

   ffmpeg_utils
