.. _ref-sindy:

deeptime.sindy
==============

The *sindy* package contains the SINDy estimator for discovering governing equations from data.

.. automodule:: deeptime.sindy

.. toctree::
   :maxdepth: 1
