# pos

PoS datasets. 

```{eval-rst}
PoS is a normal tagging task which uses :class:`hanlp.datasets.ner.loaders.tsv.TSVTaggingDataset` for loading.
```

```{toctree}
resources
```

