const ps = new PerfectScrollbar(".sphinxsidebar", {
    wheelPropagation: true
});
ps.update()
