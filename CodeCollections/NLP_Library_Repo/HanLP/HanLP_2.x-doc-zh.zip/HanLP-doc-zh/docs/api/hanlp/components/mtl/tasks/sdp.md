# sdp

Semantic Dependency Parsing.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.sdp.BiaffineSemanticDependencyParsing
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
