.. py:module:: torchaudio.prototype.datasets

torchaudio.prototype.datasets
=============================

.. currentmodule:: torchaudio.prototype.datasets

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: autosummary/dataset_class.rst

    Musan
