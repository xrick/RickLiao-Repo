download the latest VST3 SDK:

[http://www.steinberg.net/en/company/developer.html
](http://www.steinberg.net/en/company/developer.html
)

extract the zip file here preserving the folder structure so it looks like:

`Dependencies/IPlug/VST3_SDK/`  
`Dependencies/IPlug/VST3_SDK/base/source`  
`Dependencies/IPlug/VST3_SDK/base/thread`  
`Dependencies/IPlug/VST3_SDK/pluginterfaces`  
`Dependencies/IPlug/VST3_SDK/public.sdk/source`  