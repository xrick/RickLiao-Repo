#include <stdio.h>

void myFunction(void);

int main(void)
{
	printf("Function declared.");
}