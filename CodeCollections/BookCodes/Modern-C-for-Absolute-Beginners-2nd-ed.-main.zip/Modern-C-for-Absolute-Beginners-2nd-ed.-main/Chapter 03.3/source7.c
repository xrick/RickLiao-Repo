#include <stdio.h>

int main(void)
{
	unsigned char mychar = 255;
	printf("The value of mychar is: %d", mychar);
}