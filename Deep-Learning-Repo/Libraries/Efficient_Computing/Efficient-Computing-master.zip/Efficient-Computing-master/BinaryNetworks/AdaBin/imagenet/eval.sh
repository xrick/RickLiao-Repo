python main.py --data /cache/imagenet/ \
               --arch resnet18_1w1a \
               --pretrained ./checkpoints/resnet18_1w1a/model_best.pth.tar \
               --evaluate