# ner

```{eval-rst}

.. automodule:: hanlp.pretrained.ner
    :members:

```