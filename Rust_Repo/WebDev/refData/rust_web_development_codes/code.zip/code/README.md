# Rust Web Development 

Source code (WIP) for the [Rust book published with Manning](https://www.manning.com/books/rust-web-development).
