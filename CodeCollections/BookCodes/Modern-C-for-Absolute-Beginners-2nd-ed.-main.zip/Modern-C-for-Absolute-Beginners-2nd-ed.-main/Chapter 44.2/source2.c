#include <stdio.h>

int main(void)
{
	int arr[] = {10, 20, 30, 40, 50};
	int *p = arr;
	printf("The first array element is: %d\n", *p);
	p++;
	printf("The next array element is: %d\n", *p);
}