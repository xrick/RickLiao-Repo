# Results

This file is reserved for result data, resulting from the conversion of models, and their assessment using TFLite Micro