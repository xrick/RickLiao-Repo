int main(void)
{
	char c;
	int x;
	float f;
	double d;
}