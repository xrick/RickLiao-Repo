#include <stdio.h>

int main(void)
{
	short x;
	x = 1234;
	printf("The value of a short integer is: %d\n", x);

	long y;
	y = 123456789l;
	printf("The value of a long integer is: %ld\n", y);
}