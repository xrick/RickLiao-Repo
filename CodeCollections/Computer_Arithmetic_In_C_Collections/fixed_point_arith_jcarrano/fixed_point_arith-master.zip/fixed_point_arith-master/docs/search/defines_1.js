var searchData=
[
  ['fxp_5fdeclaration',['FXP_DECLARATION',['../quaternion_8h.html#a4d821e3413959a460e01c82efa2cf464',1,'FXP_DECLARATION():&#160;quaternion.h'],['../vector_8h.html#a4d821e3413959a460e01c82efa2cf464',1,'FXP_DECLARATION():&#160;vector.h']]],
  ['fxp_5fdeclaration_5fc99_5fbody',['FXP_DECLARATION_C99_BODY',['../common_8h.html#a5637cf811046051ce9a20f0d9ad1fee8',1,'common.h']]],
  ['fxp_5fdeclaration_5fc99_5fheader',['FXP_DECLARATION_C99_HEADER',['../common_8h.html#a826cea0fcb6781f5a946edc983dc3a46',1,'common.h']]]
];
