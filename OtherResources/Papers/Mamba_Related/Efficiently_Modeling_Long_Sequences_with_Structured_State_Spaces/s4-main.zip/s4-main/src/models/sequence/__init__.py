from .base import SequenceModule, TransposedModule
