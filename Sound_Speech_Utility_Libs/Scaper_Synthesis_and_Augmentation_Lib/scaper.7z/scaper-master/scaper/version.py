#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = '1.6'
version = '1.6.5'
