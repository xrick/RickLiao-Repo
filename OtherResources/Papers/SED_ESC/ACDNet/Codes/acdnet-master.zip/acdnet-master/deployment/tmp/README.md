# Tmp

This folder is reserved to assist the generation of tflite and c++ files needed to evaluate models 