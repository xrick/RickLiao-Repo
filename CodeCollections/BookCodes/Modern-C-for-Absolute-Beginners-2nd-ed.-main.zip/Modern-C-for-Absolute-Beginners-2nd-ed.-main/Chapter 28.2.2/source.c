#include <stdio.h>

int main(void)
{
	puts("This is a puts() message.");
}