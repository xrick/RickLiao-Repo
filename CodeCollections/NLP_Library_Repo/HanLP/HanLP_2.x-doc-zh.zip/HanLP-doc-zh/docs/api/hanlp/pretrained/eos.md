# eos


```{eval-rst}

.. automodule:: hanlp.pretrained.eos
    :members:

```