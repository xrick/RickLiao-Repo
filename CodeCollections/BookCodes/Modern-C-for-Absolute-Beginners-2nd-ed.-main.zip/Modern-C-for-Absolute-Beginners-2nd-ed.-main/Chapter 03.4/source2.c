int main(void)
{
	int x;
	x = 10;  // decimal constant
	int y;
	y = 012; // octal constant
	int z;
	z = 0xA; // hexadecimal constant
}