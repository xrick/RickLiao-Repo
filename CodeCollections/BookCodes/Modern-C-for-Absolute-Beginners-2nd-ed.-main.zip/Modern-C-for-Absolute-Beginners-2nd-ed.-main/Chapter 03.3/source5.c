#include <stdio.h>

int main(void)
{
	char mychar;
	mychar = 'a';
	printf("%d", mychar);
}