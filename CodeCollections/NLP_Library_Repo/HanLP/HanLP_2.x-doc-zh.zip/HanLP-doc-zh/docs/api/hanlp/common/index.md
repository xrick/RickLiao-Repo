# common

Common base classes.

```{toctree}
structure
vocab
transform
dataset
component
torch_component
```

