#include <uchar.h>

int main(void)
{
	char16_t arr16[] = u"Our 16-bit wide characters here.\n";
	char32_t arr32[] = U"Our 32-bit wide characters here.\n";
}