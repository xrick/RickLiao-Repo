var searchData=
[
  ['efrac_5fbase',['efrac_base',['../group__fxp__class.html#ga2301e41e09aa77be4620cdc297e6e023',1,'types.h']]]
];
