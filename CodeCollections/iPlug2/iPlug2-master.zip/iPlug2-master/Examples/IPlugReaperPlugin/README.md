# IPlugReaperPlugin
A plug-in that demonstrates how to use the REAPER SDK (VST2, VST3 and CLAP formats)

The VST2 and VST3 builds suppor REAPER's embedded UI

https://github.com/justinfrankel/reaper-sdk
https://www.reaper.fm/sdk/vst/vst_ext.php