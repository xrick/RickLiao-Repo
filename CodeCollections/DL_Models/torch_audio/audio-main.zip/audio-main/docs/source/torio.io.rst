.. py:module:: torio.io

torio.io
========

.. currentmodule:: torio.io

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: autosummary/torio_io_class.rst

   StreamingMediaDecoder
   StreamingMediaEncoder

.. rubric:: Tutorials using ``torio.io``

.. minigallery:: torio.io

.. minigallery:: torchaudio.io
