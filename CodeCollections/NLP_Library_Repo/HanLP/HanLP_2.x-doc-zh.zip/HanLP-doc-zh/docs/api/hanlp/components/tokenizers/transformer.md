# transformer

Transformer based tokenizer.

```{eval-rst}
.. currentmodule:: hanlp.components.tokenizers.transformer

.. autoclass:: hanlp.components.tokenizers.transformer.TransformerTaggingTokenizer
	:members:

```
