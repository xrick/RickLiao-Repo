while True:
    print("Hello World !")
