#include <stdio.h>

void printMessage()
{
	printf("Hello World! from a function.\n");
}

int main(void)
{
	printMessage();
}