.. _ref-data:

deeptime.data
=============
The *data* package contains example systems.

.. automodule:: deeptime.data

.. toctree::
   :maxdepth: 1
