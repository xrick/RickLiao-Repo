C-Algorithms
============

Random experiments in C

### Compiling

Use `gcc` to compile as `cc` does not recognize stdbool.h file

### Running

Run the generated executable by typing the filename in the terminal
