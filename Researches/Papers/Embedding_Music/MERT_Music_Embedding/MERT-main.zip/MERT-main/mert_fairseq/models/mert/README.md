add cauchy extension from https://github.com/HazyResearch/state-spaces
```shell
cd state-spaces/extensions/cauchy
python setup.py install
```
