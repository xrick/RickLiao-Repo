# conll2012_dataset

```{eval-rst}

.. autoclass:: hanlp.datasets.srl.loaders.conll2012.CoNLL2012SRLDataset
	:members:

```
