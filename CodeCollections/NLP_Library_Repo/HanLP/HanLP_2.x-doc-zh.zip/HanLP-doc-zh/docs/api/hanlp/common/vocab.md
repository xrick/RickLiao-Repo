# vocab

```{eval-rst}
.. currentmodule:: hanlp.common

.. autoclass:: hanlp.common.transform.Vocab
	:members:
	:special-members:
	:exclude-members: __init__, __repr__, __call__, __str__

```
