# basic_audio_analysis

This is the Jupyter notebook for a quick intro to audio analysis (feature extraction, classification, regression and segmentation), as presented [in this article](https://hackernoon.com/intro-to-audio-analysis-recognizing-sounds-using-machine-learning-qy2r3ufl)
