import spectral_benchmark

