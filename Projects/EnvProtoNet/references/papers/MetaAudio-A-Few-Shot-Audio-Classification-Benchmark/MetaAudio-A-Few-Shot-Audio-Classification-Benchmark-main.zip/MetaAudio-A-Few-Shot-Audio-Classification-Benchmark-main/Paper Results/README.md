## Paper Results
In our paper we present baseline results for a variety of experimental settings. These are included here also for reference. We invite the community to build upon these results with new algorithms and techniques. 

# Headline
![alt text](headline.png)

# External Data 
![alt text](external.png)
