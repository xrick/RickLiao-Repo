from featuretools.primitives.base import TransformPrimitive


class NewPrimitive(TransformPrimitive):
    """A primitive that should not currently exist for testing."""

    pass
