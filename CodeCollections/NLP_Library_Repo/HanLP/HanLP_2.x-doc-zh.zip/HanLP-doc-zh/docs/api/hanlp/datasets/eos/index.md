# eos

Sentence boundary detection datasets.

```{toctree}
eos
resources
```

