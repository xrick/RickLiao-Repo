# transformer_ner

Tagging based Named Entity Recognition.

```{eval-rst}
.. currentmodule:: hanlp.components.ner.transformer_ner

.. autoclass:: hanlp.components.ner.transformer_ner.TransformerNamedEntityRecognizer
	:members:

```
