# kpca_lda_knn_equalizeClasses.py 
  script is using KernalPCA as a first step to reduce the dimension of the data and then LDA to bring the data
  into the dimension class -1 and then using knn. Same as the script 
 # kpca_lda_multiclass.py
 for 3 classes.
  # pca_kpca_from-skratch.py
Implementation of Principal Component Analysis and KernelPCA from skratch
# graph_spectral_analysis&spectral_clustering.py
Apply dimensionality reduction using graph spectral analysis (LLE, IsoMap etc) and then spectral clustering
