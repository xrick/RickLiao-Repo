#include <stdio.h>
#include <float.h>

int main(void)
{
	printf("The maximum value for a float is: %f\n", FLT_MAX);
}