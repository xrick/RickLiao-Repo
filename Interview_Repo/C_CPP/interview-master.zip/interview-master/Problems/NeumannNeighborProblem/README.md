
## 冯诺依曼邻居问题

### 问题说明

某算法从一个1×1的方格开始，每次都会在上次图形的周围再加上一圈方格，在第n次的时候要生成多少个方格？下图给出了n = 0，1，2是的结果。

![](https://huihut-img.oss-cn-shenzhen.aliyuncs.com/NeumannNeighborProblem.jpg)

### 解法

* [通项公式解法](Formula)
* [递推关系解法](Recursive)