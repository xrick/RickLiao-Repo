# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-06-17 11:31
# 《自然语言处理入门》第 4 章 隐马尔可夫模型与序列标注
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
