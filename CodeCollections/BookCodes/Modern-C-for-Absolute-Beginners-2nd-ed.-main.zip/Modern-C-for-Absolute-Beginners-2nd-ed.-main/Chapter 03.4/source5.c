#include <stdio.h>

int main(void)
{
	unsigned x = 123456789u;
	printf("The value of an unsigned integer is: %u", x);
}