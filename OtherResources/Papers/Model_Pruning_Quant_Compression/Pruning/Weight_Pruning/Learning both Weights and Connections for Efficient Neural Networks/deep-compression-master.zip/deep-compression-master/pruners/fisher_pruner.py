import torch
import random
import numpy as np

from models import *


class FisherPruner:
    def get_fisher(self, model):
        pass

    def prune(self, model, prune_rate):
        pass
