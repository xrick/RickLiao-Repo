swipe
==============

.. automodule:: libf0.swipe
    :members:
    :undoc-members:
