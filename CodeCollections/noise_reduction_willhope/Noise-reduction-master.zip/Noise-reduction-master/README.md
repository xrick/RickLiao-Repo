# Noise-reduction
Noise reduction using Log_MMSE method   implement by C language
