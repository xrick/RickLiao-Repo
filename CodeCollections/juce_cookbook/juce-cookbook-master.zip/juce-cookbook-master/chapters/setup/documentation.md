# Documentation

## Doxygen

- [Example: tobanteAudio/modEQ](https://tobanteaudio.github.io/modEQ/)

## GitHub Pages

### static files

### readthedocs

### gitbook
