int main(void)
{
	char c = 'a';
	int x = 123;
	float f = 123.456f;
	double d = 789.101112;
}