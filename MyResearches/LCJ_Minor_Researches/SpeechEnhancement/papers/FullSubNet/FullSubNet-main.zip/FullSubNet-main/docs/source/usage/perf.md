# Performance

![perf](fullsubnet-result.png)