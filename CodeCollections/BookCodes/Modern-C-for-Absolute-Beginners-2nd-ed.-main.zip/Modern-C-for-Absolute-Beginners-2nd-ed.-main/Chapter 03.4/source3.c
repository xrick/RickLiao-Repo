#include <stdio.h>

int main(void)
{
	int x;
	x = 10;
	printf("Decimal: %d Octal: %o Hexadecimal: %X", x, x, x);
}