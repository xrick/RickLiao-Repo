#ifndef MYHEADERFILE_H
#define MYHEADERFILE_H

void myfunction(); // function declaration
// this function is defined inside the source2.c file


#endif