#include <stdio.h>
#include <time.h>
 
int main(void)
{
	time_t mytime = time(NULL);
	printf("Obtained the current time to a mytime variable.\n");
}