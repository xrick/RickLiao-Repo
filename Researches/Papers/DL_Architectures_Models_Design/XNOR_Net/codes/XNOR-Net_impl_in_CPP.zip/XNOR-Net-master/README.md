# XNOR-Net (The best training effect of AlexNet-Xnor is around 40%, 4% lower than the paper).
