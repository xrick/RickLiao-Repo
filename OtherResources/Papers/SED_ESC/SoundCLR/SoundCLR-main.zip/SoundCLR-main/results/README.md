The results from training/ testing the models will be saved in this folder
