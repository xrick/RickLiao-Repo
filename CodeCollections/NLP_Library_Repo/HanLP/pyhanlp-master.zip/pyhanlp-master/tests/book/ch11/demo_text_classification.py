# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2019-01-04 20:28
# 《自然语言处理入门》11.4.2 朴素贝叶斯文本分类器实现
# 请参考tests/demos/demo_text_classification.py
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
