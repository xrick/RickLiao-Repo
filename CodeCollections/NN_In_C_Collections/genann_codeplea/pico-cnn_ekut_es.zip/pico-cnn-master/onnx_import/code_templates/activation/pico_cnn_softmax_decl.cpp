    pico_cnn::naive::Softmax *{{identifier}}_layer;
