# Benchmark

- [`Google Benchmark`](https://github.com/google/benchmark)
- Generate test data
  - Noise
  - Sample
- Simple example
