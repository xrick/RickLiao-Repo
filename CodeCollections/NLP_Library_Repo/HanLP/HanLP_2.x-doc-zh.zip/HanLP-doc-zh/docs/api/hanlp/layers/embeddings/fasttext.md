# fasttext

```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.fast_text.FastTextEmbedding
	:members:

.. autoclass:: hanlp.layers.embeddings.fast_text.FastTextEmbeddingModule
	:members:

```
