# structure

```{eval-rst}
.. currentmodule:: hanlp.common

.. autoclass:: hanlp.common.structure.ConfigTracker
	:members:

.. autoclass:: hanlp.common.structure.History
	:members:

```
