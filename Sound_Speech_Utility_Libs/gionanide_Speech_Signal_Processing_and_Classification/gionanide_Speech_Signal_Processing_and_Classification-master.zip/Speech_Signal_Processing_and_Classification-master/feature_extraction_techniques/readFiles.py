#!usr/bin/python
import os

def readCases():
	healthyCases = os.listdir('path')
	capturedCases = os.listdir('path')
	#using the os libary that Python provides to read all the files from a scertain directory
	#the function return two arrays with all the file names that are in the specific directory
