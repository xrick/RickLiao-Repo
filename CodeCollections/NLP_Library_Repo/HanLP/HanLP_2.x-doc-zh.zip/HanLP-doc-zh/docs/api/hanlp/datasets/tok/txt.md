# txt

```{eval-rst}
.. currentmodule:: hanlp.datasets.tokenization.loaders.txt

.. autoclass:: TextTokenizingDataset
	:members:

```
