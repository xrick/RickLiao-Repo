#include <stdio.h>
#include <limits.h>

int main(void)
{
	printf("The number of bits in a byte: %d\n", CHAR_BIT);
}