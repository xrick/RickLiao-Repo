# char_rnn


```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.char_rnn.CharRNN
	:members:

.. autoclass:: hanlp.layers.embeddings.char_rnn.CharRNNEmbedding
	:members:

```
