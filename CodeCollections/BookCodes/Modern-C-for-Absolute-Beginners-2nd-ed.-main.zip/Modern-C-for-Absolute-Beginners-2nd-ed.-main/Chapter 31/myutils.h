#ifndef MY_UTILS_H
#define MY_UTILS_H

#include <stdio.h>

void myFunction();

#endif