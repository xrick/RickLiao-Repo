#include <stdio.h>

int x = 123; // x has a global scope

int main(void)
{
	printf("X has a global scope and a value of: %d\n", x);
}