# The Annotated Encoder Decoder with Attention

Read the [blog post](https://bastings.github.io/annotated_encoder_decoder/) or simply run the jupyter notebook from this repository.
