var searchData=
[
  ['frac',['frac',['../group__fxp__class.html#structfrac',1,'']]]
];
