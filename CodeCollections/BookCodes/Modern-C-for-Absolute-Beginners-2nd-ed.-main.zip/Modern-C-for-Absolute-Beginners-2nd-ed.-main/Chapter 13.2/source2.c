#include <stdio.h>

int myFunction(int x, int y);

int main(void)
{
	printf("Function declared.\n");
}