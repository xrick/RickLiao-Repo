Place the Web Audio Modules SDK (iPlug2 fork) here

https://github.com/iPlug2/api

So it looks like this...

Dependencies/IPlug/WAM_SDK/LICENSE
Dependencies/IPlug/WAM_SDK/README.md
Dependencies/IPlug/WAM_SDK/wamsdk/processor.cpp
Dependencies/IPlug/WAM_SDK/wamsdk/processor.h
Dependencies/IPlug/WAM_SDK/wamsdk/wam-controller.js
Dependencies/IPlug/WAM_SDK/wamsdk/wam-processor.js
