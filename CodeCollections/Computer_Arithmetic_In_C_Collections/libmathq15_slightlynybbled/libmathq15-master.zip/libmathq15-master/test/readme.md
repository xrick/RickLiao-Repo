# Testing #

This directory will be used to explore edge cases and other likely-fail scenarios on different platforms, as opposed to the 'accuracy' directory which will analyze the accuracy over the range of possible values.

## MingW ##

Testing of most functions complete and passing

## Microchip XC16 ##

Testing completed and passing.

Some credit taken in the 'accuracy' directory for passing tests.
