ALTER TABLE questions
DROP COLUMN account_id;