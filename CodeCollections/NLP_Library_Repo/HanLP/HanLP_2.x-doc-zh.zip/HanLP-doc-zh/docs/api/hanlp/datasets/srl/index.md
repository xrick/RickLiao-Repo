# srl

Semantic Role Labeling datasets.

```{toctree}
conll2012_dataset
resources
```

