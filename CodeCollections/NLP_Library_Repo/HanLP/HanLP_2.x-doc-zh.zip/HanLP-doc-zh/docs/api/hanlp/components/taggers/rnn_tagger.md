# rnn_tagger

RNN based tagger.

```{eval-rst}
.. currentmodule:: hanlp.components

.. autoclass:: hanlp.components.taggers.rnn_tagger.RNNTagger
	:members:

```
