# pos

Part-of-speech tagging.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.pos.TransformerTagging
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
