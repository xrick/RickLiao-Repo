#!/usr/bin/env bash

export PYTORCH_KALDI_DIR=`pwd`
export PYTORCH_EXP=`pwd`/exp