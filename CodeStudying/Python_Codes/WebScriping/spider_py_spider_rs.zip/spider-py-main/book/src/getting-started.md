# Getting Started

Make sure to have python installed.

```sh
pip install spider_rs
```
