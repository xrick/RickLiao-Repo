#include <math.h>
#include <stdio.h>

int main(void)
{
	double x = -123.456;
	double y = 789.101;
	printf("The absolute value of x is: %f\n", fabs(x));
	printf("The absolute value of y is: %f\n", fabs(y));
}