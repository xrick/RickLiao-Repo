    pico_cnn::naive::FullyConnected *{{identifier}}_layer;
