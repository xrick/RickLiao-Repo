# resources

## nn_eos

```{eval-rst}

.. automodule:: hanlp.datasets.eos.loaders.nn_eos
    :members:

```