Contacts
----------

If any doubt, confusion or feedback please contact me at

* `n(dot)bajaj[At]imperial.ac.uk`
* `n(dot)bajaj[At]qmul.ac.uk`
* `nikkeshbajaj{At}gmail.com`

Nikesh Bajaj: http://nikeshbajaj.in

Postdoc: ***Imperial College London***
PhD: **Queen Mary University of London**
