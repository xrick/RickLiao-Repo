This folder contains snapshots of the pre-trained models.
