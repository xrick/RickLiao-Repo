.. _ref-plots:

deeptime.plots
==============

The *plots* package contains some plotting convenience utilities.

.. automodule:: deeptime.plots

.. toctree::
   :maxdepth: 1
