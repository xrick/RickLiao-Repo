# Task

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.Task
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
