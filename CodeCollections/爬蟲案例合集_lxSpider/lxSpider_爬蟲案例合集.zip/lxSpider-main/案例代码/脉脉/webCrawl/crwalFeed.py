# -*- coding: utf-8 -*-
# @Author  : lx
# @IDE ：PyCharm

'''根据《看了他的人还看了》深度采集'''

encode_mmid = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1IjozNzA1ODEzNiwibGV2ZWwiOjAsInQiOiJjdHQifQ.Wbi1oFVVxDNES0V7p50RZdbD8KjfrHLrHuOLaxRegaI"
s = f'https://maimai.cn/contact/interest_contact/{encode_mmid}?jsononly=1'

