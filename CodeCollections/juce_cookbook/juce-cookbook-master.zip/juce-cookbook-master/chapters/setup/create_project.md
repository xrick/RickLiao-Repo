# Create Project

## Projucer

- [Official JUCE: Projucer Part 1: Getting started with the Projucer](https://docs.juce.com/master/tutorial_new_projucer_project.html)
- [Official JUCE: Projucer Part 2: Manage your Projucer projects](https://docs.juce.com/master/tutorial_manage_projucer_project.html)

## CMake

- [github.com/juce-framework/JUCE/tree/juce6/examples/CMake](https://github.com/juce-framework/JUCE/tree/juce6/examples/CMake)
