constant
====================


.. automodule:: hanlp_common.constant
	:members:
