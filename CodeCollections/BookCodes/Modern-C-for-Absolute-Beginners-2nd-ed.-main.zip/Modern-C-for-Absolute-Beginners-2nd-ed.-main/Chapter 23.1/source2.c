#include <stdio.h>
#include "myheaderfile.h"

int main(void)
{
	printf("Included one standard-library header and one user-defined header file.\n");
}