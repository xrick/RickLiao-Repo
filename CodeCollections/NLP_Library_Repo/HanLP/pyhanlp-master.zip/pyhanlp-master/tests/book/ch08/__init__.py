# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-07-24 16:30
# 《自然语言处理入门》第 8 章 命名实体识别
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
