#include <math.h>
#include <stdio.h>

int main(void)
{
	printf("The value of 2 to the power of 10 is: %f\n", pow(2, 10));
	printf("The value of 2 to the power of 20 is: %f\n", pow(2, 20));
}