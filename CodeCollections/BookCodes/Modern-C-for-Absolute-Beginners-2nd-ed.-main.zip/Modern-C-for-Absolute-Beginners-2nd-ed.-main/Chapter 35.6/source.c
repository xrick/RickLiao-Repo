int main(void)
{
    int x = {
#embed "somefile.dat"
    };
}