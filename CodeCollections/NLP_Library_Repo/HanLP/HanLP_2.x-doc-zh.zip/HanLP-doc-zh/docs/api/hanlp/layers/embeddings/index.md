# embeddings

```{toctree}
embedding
word2vec
fasttext
char_cnn
char_rnn
transformer
```

