# biaffine_ner

Biaffine Named Entity Recognition.

```{eval-rst}
.. currentmodule:: hanlp.components.ner.transformer_ner

.. autoclass:: hanlp.components.ner.biaffine_ner.biaffine_ner.BiaffineNamedEntityRecognizer
	:members:

```
