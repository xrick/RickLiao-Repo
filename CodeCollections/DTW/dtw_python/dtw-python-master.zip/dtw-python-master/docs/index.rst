
.. include:: ../README.rst


API
===

.. automodapi:: dtw
		
