# span_bio

Span BIO tagging based SRL.

```{eval-rst}
.. currentmodule:: hanlp.components.srl.span_bio.span_bio

.. autoclass:: SpanBIOSemanticRoleLabeler
	:members:

```
