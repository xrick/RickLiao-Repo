#include <stdio.h>

int main(void)
{
	char arr[] = "Hello World!";
	printf("The value is: %s\n", arr);
}