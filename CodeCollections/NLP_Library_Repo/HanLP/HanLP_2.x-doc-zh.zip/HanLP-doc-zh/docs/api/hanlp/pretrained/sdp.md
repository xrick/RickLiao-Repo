# sdp

```{eval-rst}

.. automodule:: hanlp.pretrained.sdp
    :members:

```