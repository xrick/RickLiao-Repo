# Testing

- [Testing](#testing)
  - [JUCE unit tests](#juce-unit-tests)
  - [Catch2](#catch2)
  - [pluginval](#pluginval)
  - [Valgrind](#valgrind)
