# Look&Feel

## Basics

- Colour IDs
- Override functions
- Look at JUCE implementations

## Example juce::Component

## Example custom Component

- Custom components
  - Look&Feel methods
