# Protocols

Here are the JSON-files that describe configurations of experiments.
