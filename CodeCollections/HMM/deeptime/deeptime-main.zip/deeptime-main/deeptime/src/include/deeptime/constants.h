//
// Created by mho on 12/2/21.
//

#pragma once

namespace deeptime::constants {

template<typename dtype>
constexpr dtype pi() { return 3.141592653589793238462643383279502884e+00; }

}
