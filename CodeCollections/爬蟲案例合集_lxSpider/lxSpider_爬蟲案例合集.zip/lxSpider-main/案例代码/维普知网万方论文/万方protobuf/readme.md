博客链接：https://blog.csdn.net/weixin_43582101/article/details/115696541

只有请求的案例，没有解析。大家自行研究

---

补充了专利的请求解析：http://t.csdn.cn/7cmJS

---

protoc下载地址：https://github.com/protocolbuffers/protobuf/releases

---




