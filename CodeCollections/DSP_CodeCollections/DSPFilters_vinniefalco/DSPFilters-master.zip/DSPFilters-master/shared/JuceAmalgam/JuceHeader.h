// #include this header in your source files to use Juce

#ifndef __JUCEHEADER_AMALGAMATION_HEADER__
#define __JUCEHEADER_AMALGAMATION_HEADER__

#include "juce_amalgam.h"

#endif
