#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	int x = -123;
	int y = 456;
	printf("The absolute value of x is: %d\n", abs(x));
	printf("The absolute value of y is: %d\n", abs(y));
}