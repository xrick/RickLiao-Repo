# 这个包是《自然语言处理入门》的配套代码，与HanLP1.x同步更新，保持兼容。
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
