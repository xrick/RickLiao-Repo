from .atss_assigner import ATSSAssigner
from .tal_assigner import TaskAlignedAssigner
