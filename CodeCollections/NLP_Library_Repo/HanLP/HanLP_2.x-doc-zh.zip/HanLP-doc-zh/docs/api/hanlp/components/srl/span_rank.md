# span_rank

Span Rank based SRL.

```{eval-rst}
.. currentmodule:: hanlp.components.srl.span_rank.span_rank

.. autoclass:: SpanRankingSemanticRoleLabeler
	:members:

```
