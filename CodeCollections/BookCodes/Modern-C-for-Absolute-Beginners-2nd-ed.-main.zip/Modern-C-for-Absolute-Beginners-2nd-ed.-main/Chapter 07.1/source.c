#include <stdio.h>

int main(void)
{
	int x = 123;
	int y = 456;
	int z = x + y;
	printf("The result is: %d\n", z);
}