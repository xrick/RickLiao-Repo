#include <stdio.h>

int main(void)
{
	fputs("This is a fputs() message.\n", stdout);
}