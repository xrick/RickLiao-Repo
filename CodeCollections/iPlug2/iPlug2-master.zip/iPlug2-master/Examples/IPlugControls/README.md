# IPlugControls
A project to demonstrate the IGraphics control library

## Extra license info

- forkawesome icon font [license](https://forkaweso.me/Fork-Awesome/license/)
- fontaudio icon font by @fefanto [license](https://github.com/fefanto/fontaudio/blob/master/README.md#license)
- IconFontCppHeaders by @juliettef [license](https://github.com/juliettef/IconFontCppHeaders/blob/master/licence.txt)
- Vertical SVGSlider modified from Koralfx VCVRack modules by Tomek Sosnowski [license](https://github.com/koralfx/Koralfx-Modules/blob/master/LICENSE.txt)
- Horizontal SVGSlider from VCVRack core library by Grayscale [license](https://github.com/VCVRack/Rack/blob/v1/include/componentlibrary.hpp)