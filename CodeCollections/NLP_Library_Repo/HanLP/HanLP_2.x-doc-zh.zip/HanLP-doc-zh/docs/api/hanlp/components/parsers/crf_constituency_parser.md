# crf_constituency_parser

Biaffine dependency parser.

```{eval-rst}
.. currentmodule:: hanlp.components

.. autoclass:: hanlp.components.parsers.constituency.crf_constituency_parser.CRFConstituencyParser
	:members:

```
