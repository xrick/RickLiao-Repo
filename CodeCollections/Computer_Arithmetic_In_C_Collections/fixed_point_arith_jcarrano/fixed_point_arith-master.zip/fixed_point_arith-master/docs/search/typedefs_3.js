var searchData=
[
  ['mfrac_5fbase',['mfrac_base',['../group__fxp__class.html#ga4e4b8e4cbca87352fedf414558a50aeb',1,'types.h']]]
];
