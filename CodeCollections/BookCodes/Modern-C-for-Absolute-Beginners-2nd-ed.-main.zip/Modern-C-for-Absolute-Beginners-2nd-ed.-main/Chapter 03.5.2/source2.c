#include <stdio.h>

int main(void)
{
	double mydouble;
	mydouble = 123.456;
	printf("The value of a double variable is: %.3f", mydouble);
}