int main(void)
{
	int myarr[2][3] = {{1, 2, 3},
			     {4, 5, 6}};
}