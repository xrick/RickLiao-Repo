#include <stdio.h>

int main(void)
{
    unsigned x = 0b1010u;
    printf("The value of the unsigned variable x is: %u\n", x); 
}