# ner

NER datasets.

```{toctree}
tsv
json
resources
```

