Reference
#########

.. automodule:: pyphonic
    :members: getBPM, getDataDir, getSampleRate, getSignalStats, getTransport
    :undoc-members:

.. autoclass:: pyphonic.midi_parser.MidiMessage
