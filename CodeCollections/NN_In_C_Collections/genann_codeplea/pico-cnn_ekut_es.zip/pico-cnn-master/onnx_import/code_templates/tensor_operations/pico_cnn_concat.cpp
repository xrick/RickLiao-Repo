    {{input_declaration}}

    {{output_buffer.name}}->concatenate_from({{num_inputs}}, {{inputs}}, {{dimension}});

