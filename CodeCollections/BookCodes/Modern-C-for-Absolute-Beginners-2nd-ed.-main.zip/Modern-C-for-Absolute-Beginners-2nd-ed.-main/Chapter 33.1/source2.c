int main(void)
{
	_Static_assert(sizeof(long) == 8, "The size of long is not 8.\n");
}