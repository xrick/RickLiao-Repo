References
==================

.. bibliography:: references.bib
	:cited:
	:style: astrostyle