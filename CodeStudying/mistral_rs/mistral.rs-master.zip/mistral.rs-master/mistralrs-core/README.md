# `mistralrs-core`

Core crate of `mistral.rs` including the models and associated executors.

Documentation: https://ericlbuehler.github.io/mistral.rs/mistralrs/
