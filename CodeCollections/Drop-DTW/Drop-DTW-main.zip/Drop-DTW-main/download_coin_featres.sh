cd Datasets
wget https://www.eecs.yorku.ca/~kosta/COIN/COIN.zip
unzip COIN.zip
rm COIN.zip
rm -rf __MACOSX
