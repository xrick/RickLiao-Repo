#!/usr/bin/env python

import sys
import re
import os
import csv
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
from datasets import load_from_disk, Dataset
from sklearn import metrics
from transformers import Wav2Vec2CTCTokenizer, Wav2Vec2Processor, Wav2Vec2ForCTC
from tqdm import tqdm
from typing import Dict, List, Tuple, Optional
import os
import socket
from datetime import datetime

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

PHONEME_CONFUSION_MAP = {
    # Stops
    "p": ["b", "m"], "b": ["p", "m"],
    "t": ["d", "ɾ", "n"], "d": ["t", "ɾ", "n"],
    "k": ["g", "ŋ"], "g": ["k", "ŋ"],
    "ʔ": [],
    # Fricatives
    "f": ["v"], "v": ["f"],
    "θ": ["ð", "f"], "ð": ["θ", "v", "d"],
    "s": ["z", "ʃ"], "z": ["s", "ʒ"],
    "ʃ": ["ʒ", "tʃ", "s"], "ʒ": ["ʃ", "dʒ"],
    # Affricates
    "tʃ": ["ʃ", "dʒ"], "dʒ": ["ʒ", "tʃ"],
    # Nasals
    "m": ["n", "p", "b"], "n": ["m", "ŋ", "ɾ"], "ŋ": ["n", "k", "g"],
    # Liquids/Glides
    "ɹ": ["l", "w"], "l": ["ɹ", "ɫ"], "ɫ": ["o", "ʊ"],
    "j": ["dʒ"], "w": ["v"],
    # Vowels
    "i": ["ɪ", "iː"], "ɪ": ["i", "e"],
    "e": ["ɛ", "ɪ"], "ɛ": ["æ", "e"],
    "æ": ["ɑ", "ɛ"], "ɑ": ["ɔ", "ʌ"],
    "ɔ": ["ɑ", "o"], "o": ["ɔ", "ʊ"],
    "u": ["ʊ", "o"], "ʊ": ["u", "o"],
    "ʌ": ["ə", "ɜ"], "ə": ["ʌ", "ɜ", "ɚ"],
    "ɜ": ["ə", "ɚ"], "ɚ": ["ɜ", "ə"],
    # Diphthongs
    "aɪ": ["ɑ", "e"], "aʊ": ["æ", "ʌ"],
    "ɔɪ": ["ɔ", "ɪ"], "oʊ": ["o", "ʊ"],
    # Special cases
    "ɾ": ["t", "d"], "n̩": ["n", "ən"]
}

DEFAULT_CACHE_DIR = "/cache_dir"
MODEL_PATH = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"


def print_system_info():
    """
    Prints detailed system information including:
    - Start date and time
    - Hostname
    - Machine architecture
    """
    # Get the current date and time
    start_time = datetime.now()
    print(f"Script started at: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    # Get hostname details
    full_hostname = socket.gethostname()
    fqdn = socket.getfqdn()
    os_details = os.uname()
    machine_architecture = os_details.machine

    print(f"Full hostname: {full_hostname}")
    print(f"FQDN: {fqdn}")
    print(f"Machine Architecture: {machine_architecture}")

    # Return start_time for potential runtime calculations
    return start_time


def create_confusion_id_map(tokenizer: Wav2Vec2CTCTokenizer) -> Dict[int, List[int]]:
    """Convert phoneme symbols to model token IDs with validation."""
    confusion_map = {}
    for phoneme, confusions in PHONEME_CONFUSION_MAP.items():
        try:
            phoneme_id = tokenizer._convert_token_to_id(phoneme)
            confusion_ids = [tokenizer._convert_token_to_id(c) for c in confusions]
            confusion_map[phoneme_id] = confusion_ids
        except KeyError as e:
            logger.warning(f"Skipping phoneme {phoneme}: {str(e)}")
    return confusion_map

def initialize_components() -> Tuple[Wav2Vec2Processor, Wav2Vec2CTCTokenizer, Wav2Vec2ForCTC]:
    """Initialize model components with proper caching and configuration."""
    processor = Wav2Vec2Processor.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    model = Wav2Vec2ForCTC.from_pretrained(MODEL_PATH, cache_dir=DEFAULT_CACHE_DIR)
    model.eval()
    return processor, tokenizer, model

def make_deletion(labels: torch.Tensor, pos: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Create two sequences:
      1) The original label sequence (unchanged).
      2) The label sequence with the label at index `pos` removed.

    Args:
        labels (torch.Tensor): 1D tensor of label IDs, shape (L,).
        pos (int): Index to remove in the label sequence.

    Returns:
        Tuple[torch.Tensor, torch.Tensor]:
            - First element is the original labels (same as input).
            - Second element is the modified labels with the label at `pos` deleted.

    Raises:
        ValueError: If `pos` is out of range for the labels.
    """
    if not (0 <= pos < labels.shape[0]):
        raise ValueError(
            f"Position pos={pos} is out of range for labels of length {labels.shape[0]}."
        )

    # Return both original and new sequence with the label at pos removed
    return labels, torch.cat((labels[:pos], labels[pos + 1 :]))


def get_allowed_tokens(
    phone: int,
    dictionary: Dict[int, List[int]],
    blank: int,
    num_tokens: int
) -> List[int]:
    """
    Determine which tokens are allowed for a given 'phone' ID.

    We always include 'blank'. If 'phone' is in the dictionary, we also include
    those mapped confusion IDs. Otherwise, we allow any token from 0..(num_tokens-1).

    Args:
        phone (int): The label (phone) ID for which we want the confusion set.
        dictionary (Dict[int, List[int]]): Mapping {phone_id -> list of confusion IDs}.
        blank (int): Index of the blank token.
        num_tokens (int): Total number of tokens (including blank).

    Returns:
        List[int]: The list of allowed token IDs.
    """
    if phone in dictionary:
        dict_tokens = dictionary[phone]
        allowed = set(dict_tokens) | {blank}  # union with blank
        return sorted(list(allowed))
    else:
        # If not in dictionary, allow every token [0..num_tokens-1].
        return list(range(num_tokens))


def get_alpha_bar(
    alphas: torch.Tensor,
    t: int,
    blank: int,
    pos: int
) -> torch.Tensor:
    """
    Compute a scaling factor for normalization at time t, specifically designed
    for a scenario with an 'arbitrary' state at index pos in the extended sequence.

    Args:
        alphas (torch.Tensor): The forward-probability tensor of shape (L, T, P).
        t (int): Current time index in [0..T-1].
        blank (int): Index of the blank token.
        pos (int): The label sequence position that is 'arbitrary' (wildcard).

    Returns:
        torch.Tensor: A single scalar (0D tensor) with the normalization factor.
    """
    # The extended sequence index for pos is 2 * pos + 1
    arbitrary_state = 2 * pos + 1
    alpha_mask = torch.ones(alphas.shape[2], dtype=torch.bool, device=alphas.device)
    alpha_mask[blank] = False

    # Sum of all probability from states except:
    #   - the single dimension [blank] at arbitrary_state
    #   - or the entire dimension if we want a custom approach
    return (
        alphas[:arbitrary_state, t, 0].sum()
        + alphas[arbitrary_state + 1 :, t, 0].sum()
        + alphas[arbitrary_state, t, alpha_mask].sum()
    )


def ctc_loss_with_dictionary(
    params: torch.Tensor,
    seq: torch.Tensor,
    pos: int,
    blank: int = 0,
    substitution_mapping: Optional[Dict[int, List[int]]] = None
) -> torch.Tensor:
    """
    A CTC-like forward pass that:
      - Focuses on a single 'pos' in 'seq' for expansions (a wildcard/confusion).
      - If `seq[pos]` is in `substitution_mapping`, we treat that label as any
        in the confusion list (and optionally blank) at that position.
      - All other positions behave like standard CTC.

    Args:
        params (torch.Tensor):
            A (P, T) tensor of posterior probabilities (softmax outputs) where
            P = number of tokens, T = number of time steps.
        seq (torch.Tensor):
            1D tensor of shape (L,) representing the label sequence (phone IDs).
        pos (int):
            The position in the label sequence at which we apply confusion expansions.
        blank (int, optional):
            Index for the blank token. Defaults to 0.
        substitution_mapping (dict, optional):
            Maps { original_label_id -> [list of confusion label IDs] }.
            If None, no confusion expansions are applied.

    Returns:
        torch.Tensor: A scalar tensor representing the negative log-likelihood (CTC loss).

    Raises:
        ValueError: If `params` does not have shape (P, T).
        ValueError: If `pos` is out of range of the label sequence.
    """
    # Basic validation
    if params.dim() != 2:
        raise ValueError(
            f"params must be 2D of shape (P, T). Got shape {params.shape}."
        )
    P, T = params.shape
    if not (0 <= pos < seq.shape[0]):
        raise ValueError(
            f"'pos'={pos} is invalid for seq length={seq.shape[0]}."
        )

    seq_len = seq.shape[0]
    L = 2 * seq_len + 1  # extended sequence length for typical CTC

    # alphas[s, t, p]
    alphas = torch.zeros((L, T, P), dtype=torch.double, device=params.device)
    alpha_bar = torch.zeros(T, dtype=torch.double, device=params.device)

    # ----- (1) Initialization -----
    # s=0 -> blank
    alphas[0, 0, blank] = params[blank, 0]
    # s=1 -> first label
    first_label = int(seq[0].item())
    if pos == 0 and substitution_mapping and first_label in substitution_mapping:
        # expand
        expansions = substitution_mapping[first_label]
        for token_id in expansions:
            alphas[1, 0, token_id] = params[token_id, 0]
    else:
        # normal first label
        alphas[1, 0, first_label] = params[first_label, 0]

    # normalize at t=0
    alpha_bar[0] = alphas[:, 0, :].sum()
    alphas[:, 0, :] /= alpha_bar[0]

    # ----- (2) Forward pass -----
    for t in range(1, T):
        for s in range(L):
            if s == 0:
                # s=0 => blank
                alphas[s, t, blank] = alphas[s, t - 1, blank] * params[blank, t]
            else:
                if s % 2 == 0:
                    # even s => blank
                    prev_blank_prob = alphas[s, t - 1, blank]
                    from_label_prob = alphas[s - 1, t - 1, :].sum() if (s - 1) >= 0 else 0.0
                    alphas[s, t, blank] = (prev_blank_prob + from_label_prob) * params[blank, t]
                else:
                    # odd s => actual label from seq[s//2]
                    label_idx = int(seq[s // 2].item())

                    # If this is the 'pos' (wildcard) and label_idx is in mapping
                    if (
                        (s // 2) == pos
                        and substitution_mapping
                        and (label_idx in substitution_mapping)
                    ):
                        expansions = substitution_mapping[label_idx]
                        # sum over expansions from previous step
                        stay_prob = alphas[s, t - 1, expansions].sum()
                        from_blank_prob = alphas[s - 1, t - 1, blank] if (s - 1) >= 0 else 0.0
                        total_incoming = stay_prob + from_blank_prob

                        for token_id in expansions:
                            alphas[s, t, token_id] = total_incoming * params[token_id, t]
                    else:
                        # normal CTC for single label
                        stay_prob = alphas[s, t - 1, label_idx]
                        from_blank_prob = alphas[s - 1, t - 1, blank] if (s - 1) >= 0 else 0.0
                        alphas[s, t, label_idx] = (
                            stay_prob + from_blank_prob
                        ) * params[label_idx, t]

        # normalize at time t
        alpha_bar[t] = alphas[:, t, :].sum()
        alphas[:, t, :] /= alpha_bar[t]

    # ----- (3) Negative log-likelihood -----
    ll_forward = torch.log(alpha_bar).sum()
    return -ll_forward


def process_and_save_gop(dataset, processor, model, p_tokenizer, substitution_mapping, output_csv):
    """
    Process the dataset to calculate GOP scores and save the results in a CSV file.

    Args:
        dataset: The dataset to process.
        processor: Wav2Vec2Processor for input processing.
        model: Wav2Vec2ForCTC model.
        p_tokenizer: Tokenizer for phonetic transcriptions.
        substitution_mapping: Mapping for substitutions.
        output_csv: Path to save the resulting CSV.
    """
    fieldnames = ["uttid", "simulated_phone", "actual_phone", "gop_score", "mispronounced"]
    
    # Step 1: Write CSV header before processing starts
    with open(output_csv, mode="w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()

    # Step 2: Process the dataset and write results incrementally
    with torch.no_grad():
        with open(output_csv, mode="a", newline="") as file:  # Append mode
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            for entry in tqdm(dataset, desc="Processing entries for GOP scores"):
                try:
                    # Process audio and labels
                    input_values = processor(entry["audio"]["array"], return_tensors="pt", sampling_rate=16000).input_values
                    simulated_labels = torch.tensor(
                        p_tokenizer.convert_tokens_to_ids(entry["simulated_error_transcript"]), dtype=torch.int32
                    )

                    # Forward pass
                    return_dict = model(input_values, labels=simulated_labels)
                    logits = return_dict["logits"].squeeze(0)
                    post_mat = logits.softmax(dim=-1).type(torch.float64)
                    ll_self = model(input_values, labels=simulated_labels).loss.item()

                    # Compute GOP scores
                    pids = simulated_labels.tolist()
                    for i, simulated_phone_id in enumerate(pids):
                        label_list = make_deletion(simulated_labels, i)
                        assert len(label_list) == 2
                        ll_denom = ctc_loss_with_dictionary(post_mat.transpose(0, 1), label_list[0], i, blank=0, substitution_mapping=substitution_mapping)
                        gop = -ll_self + ll_denom

                        # Extract corresponding phones
                        simulated_phone = entry["simulated_error_transcript"][i]
                        actual_phone = entry["transcript"][i]
                        mispronounced = simulated_phone != actual_phone  # Check for mispronunciation

                        # Write result to CSV immediately
                        writer.writerow({
                            "uttid": entry["audio"]["path"],
                            "simulated_phone": simulated_phone,
                            "actual_phone": actual_phone,
                            "gop_score": gop.item(),
                            "mispronounced": mispronounced
                        })
                        file.flush()  # Force immediate write to disk
                except Exception as e:
                    print(f"Error processing entry {entry.get('audio', {}).get('path', 'UNKNOWN')}: {str(e)}")

if __name__ == "__main__":
    dataset_path = "/data/mpc/simulated_error_mpc"
    prep_path = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"
    cache_dir = "/cache_dir"
    output_csv = "/paaf_rps.csv"
    start_time = print_system_info()
    # Initialize processor, tokenizer, and model
    processor, tokenizer, model = initialize_components()
    substitution_mapping = create_confusion_id_map(tokenizer)

    # Load dataset
    dataset = load_from_disk(dataset_path)
    #dataset = dataset.shuffle(seed=50).select(range(2))

    # Process dataset and save GOP scores
    process_and_save_gop(dataset, processor, model, tokenizer, substitution_mapping, output_csv)

    print("GOP scores saved to", output_csv)


