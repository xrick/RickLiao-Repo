# cmsis-pack-examples resources

* sample_image.png
* sample_audio.wav

# Sample data

The sample image and audio files are provided under the Apache 2.0 license, see [License](../LICENSE).
