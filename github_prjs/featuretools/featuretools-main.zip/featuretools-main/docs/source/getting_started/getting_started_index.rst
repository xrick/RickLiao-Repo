Getting Started
---------------

For a quick introduction to Featuretools, check out our :ref:`5 minute quick start guide <quick-start>`.

How to start working with Featuretools; the main concepts:

.. toctree::
   :maxdepth: 1

   using_entitysets
   afe
   primitives
   woodwork_types
   handling_time
