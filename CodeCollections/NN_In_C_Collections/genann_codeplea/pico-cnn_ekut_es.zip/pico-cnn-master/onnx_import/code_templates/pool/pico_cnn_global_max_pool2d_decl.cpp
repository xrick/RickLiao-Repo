    pico_cnn::naive::GlobalMaxPooling *{{identifier}}_layer;
