#!/usr/bin/env python3
"""
Goodness of Pronunciation (GOP) Calculation Pipeline using CTC loss and substitution mappings
"""

import csv
import logging
from pathlib import Path
from typing import Dict, List, Tuple

import torch
import numpy as np
from datasets import load_from_disk
from tqdm import tqdm
from transformers import Wav2Vec2CTCTokenizer, Wav2Vec2Processor, Wav2Vec2ForCTC

# Configuration Constants
MODEL_PATH = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"
CACHE_DIR = Path("/cache_dir")
DATASET_PATH = Path("/data/spo762/so_everything_cmu_ipa")
OUTPUT_CSV = Path("/ppaf_rps.csv")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PHONEME_CONFUSION_MAP = {
    # Stops
    "p": ["b", "m"], "b": ["p", "m"],
    "t": ["d", "ɾ", "n"], "d": ["t", "ɾ", "n"],
    "k": ["g", "ŋ"], "g": ["k", "ŋ"],
    "ʔ": [],
    # Fricatives
    "f": ["v"], "v": ["f"],
    "θ": ["ð", "f"], "ð": ["θ", "v", "d"],
    "s": ["z", "ʃ"], "z": ["s", "ʒ"],
    "ʃ": ["ʒ", "tʃ", "s"], "ʒ": ["ʃ", "dʒ"],
    # Affricates
    "tʃ": ["ʃ", "dʒ"], "dʒ": ["ʒ", "tʃ"],
    # Nasals
    "m": ["n", "p", "b"], "n": ["m", "ŋ", "ɾ"], "ŋ": ["n", "k", "g"],
    # Liquids/Glides
    "ɹ": ["l", "w"], "l": ["ɹ", "ɫ"], "ɫ": ["o", "ʊ"],
    "j": ["dʒ"], "w": ["v"],
    # Vowels
    "i": ["ɪ", "iː"], "ɪ": ["i", "e"],
    "e": ["ɛ", "ɪ"], "ɛ": ["æ", "e"],
    "æ": ["ɑ", "ɛ"], "ɑ": ["ɔ", "ʌ"],
    "ɔ": ["ɑ", "o"], "o": ["ɔ", "ʊ"],
    "u": ["ʊ", "o"], "ʊ": ["u", "o"],
    "ʌ": ["ə", "ɜ"], "ə": ["ʌ", "ɜ", "ɚ"],
    "ɜ": ["ə", "ɚ"], "ɚ": ["ɜ", "ə"],
    # Diphthongs
    "aɪ": ["ɑ", "e"], "aʊ": ["æ", "ʌ"],
    "ɔɪ": ["ɔ", "ɪ"], "oʊ": ["o", "ʊ"],
    # Special cases
    "ɾ": ["t", "d"], "n̩": ["n", "ən"]
}

def initialize_components() -> Tuple[Wav2Vec2Processor, Wav2Vec2CTCTokenizer, Wav2Vec2ForCTC]:
    """Initialize model components with proper caching and configuration."""
    processor = Wav2Vec2Processor.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    model = Wav2Vec2ForCTC.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    model.eval()
    return processor, tokenizer, model

def create_confusion_id_map(tokenizer: Wav2Vec2CTCTokenizer) -> Dict[int, List[int]]:
    """Convert phoneme symbols to model token IDs with validation."""
    confusion_map = {}
    for phoneme, confusions in PHONEME_CONFUSION_MAP.items():
        try:
            phoneme_id = tokenizer._convert_token_to_id(phoneme)
            confusion_ids = [tokenizer._convert_token_to_id(c) for c in confusions]
            confusion_map[phoneme_id] = confusion_ids
        except KeyError as e:
            logger.warning(f"Skipping phoneme {phoneme}: {str(e)}")
    return confusion_map

def select_subset(dataset, sample_size: int = 2):
    """Select a random subset of the dataset for testing."""
    return dataset.shuffle().select(range(sample_size))

def process_utterance(datum, processor, tokenizer, model, substitution_map):
    """Process a single utterance and calculate GOP scores."""
    try:
        # Audio processing
        input_values = processor(
            datum["audio"]["array"],
            return_tensors="pt",
            sampling_rate=16000
        ).input_values
        
        # Convert transcription to token IDs
        labels = torch.tensor(
            tokenizer.convert_tokens_to_ids(datum["cmu_ipa_phonetic_transcription"]),
            dtype=torch.int32
        )
        
        # Calculate original loss
        with torch.no_grad():
            original_loss = model(input_values, labels=labels).loss.item()
        
        per_phoneme_perturbations = {}
        for idx, phone_id in enumerate(labels.tolist()):
            phoneme_perturbations = []
            
            # Substitutions for this phoneme
            if phone_id in substitution_map:
                for sub_id in substitution_map[phone_id]:
                    new_labels = labels.clone()
                    new_labels[idx] = sub_id
                    phoneme_perturbations.append(new_labels)
            
            # Deletion for this phoneme
            if labels.shape[0] > 1:
                deleted_labels = torch.cat([labels[:idx], labels[idx+1:]])
                phoneme_perturbations.append(deleted_labels)
            
            per_phoneme_perturbations[idx] = phoneme_perturbations

        # Calculate losses PER PHONEME
        results = []
        for idx, phone in enumerate(datum["cmu_ipa_phonetic_transcription"]):
            perturb_losses = []
            
            # Process only perturbations for this specific phoneme
            for perturbed_labels in per_phoneme_perturbations.get(idx, []):
                with torch.no_grad():
                    try:
                        loss = model(input_values, labels=perturbed_labels).loss.item()
                        perturb_losses.append(loss)
                    except Exception as e:
                        logger.debug(f"Skipping invalid perturbation: {str(e)}")
            
            # Calculate GOP for this phoneme
            if perturb_losses:
                best_perturb_loss = min(perturb_losses)
                gop_score = best_perturb_loss - original_loss
                optimality = "optimal" if gop_score >= 0 else "suboptimal"
            else:
                gop_score = None
                optimality = "unknown"
            
            results.append({
                "uttid": Path(datum["uttid"]).name,
                "actual_phoneme": phone,
                "GOP": gop_score,
                "optimality": optimality,
                "mispronounced": datum.get("mispronounced", False)
            })

        return results
    
    except Exception as e:
        logger.error(f"Error processing {datum.get('audio', {}).get('path', 'unknown')}: {str(e)}")
        return []

def main(test_mode: bool = True):
    """Main execution pipeline."""
    processor, tokenizer, model = initialize_components()
    substitution_map = create_confusion_id_map(tokenizer)
    
    # Load and prepare dataset
    dataset = load_from_disk(DATASET_PATH)
    #dataset = full_dataset.map(lambda x: {
    #    'transcription': x['phonetic_transcription_ipa'].split()
    #}).remove_columns(['phonetic_transcription_ipa'])
    
    # Select subset for testing
    processed_dataset = select_subset(dataset, 2) if test_mode else dataset
    
    # Process dataset and write results
    with open(OUTPUT_CSV, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["uttid", "actual_phoneme", "GOP", "optimality", "mispronounced"])
        writer.writeheader()
        
        for datum in tqdm(processed_dataset, desc="Processing utterances"):
            results = process_utterance(datum, processor, tokenizer, model, substitution_map)
            for result in results:
                writer.writerow(result)

if __name__ == "__main__":
    # Run in test mode (small subset), set test_mode=False for full run
    main(test_mode=False)
