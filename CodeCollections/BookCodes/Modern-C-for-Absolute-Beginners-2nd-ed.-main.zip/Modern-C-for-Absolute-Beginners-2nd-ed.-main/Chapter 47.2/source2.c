#include "myheaderfile.h"
#include <stdio.h>

// function definition
void myfunction(void)
{
	printf("This function is defined inside the source2.c.\n");
}