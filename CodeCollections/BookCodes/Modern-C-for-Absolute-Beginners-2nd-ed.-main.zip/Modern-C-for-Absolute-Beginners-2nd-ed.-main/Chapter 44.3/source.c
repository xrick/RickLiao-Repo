#include <stdio.h>

int main(void)
{
	char *str = "Hello World!";
	printf("The value is: %s\n", str);
}