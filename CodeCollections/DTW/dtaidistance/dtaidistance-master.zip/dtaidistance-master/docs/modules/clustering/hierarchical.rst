
.. automodule:: dtaidistance.clustering.hierarchical
   :members:
   :undoc-members:
   :inherited-members:
