#include <stdio.h>

int main(void)
{
	// this is a comment
	/* This is an
	multi-line comment */
	printf("Hello World.\n");
	printf("C rocks!.\n");
}