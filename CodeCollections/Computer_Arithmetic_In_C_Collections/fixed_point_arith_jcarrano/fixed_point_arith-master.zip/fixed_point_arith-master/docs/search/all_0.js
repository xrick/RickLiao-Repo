var searchData=
[
  ['_5ffxp_5finline_5fkw',['_FXP_INLINE_KW',['../quaternion_8h.html#a4f0c3651de255e91a34f21ab7803c820',1,'_FXP_INLINE_KW():&#160;quaternion.h'],['../vector_8h.html#a4f0c3651de255e91a34f21ab7803c820',1,'_FXP_INLINE_KW():&#160;vector.h']]],
  ['_5ffxp_5finline_5fproto_5fkw',['_FXP_INLINE_PROTO_KW',['../quaternion_8h.html#a70679b95ecd6ab2100dbb16bfa9950a4',1,'_FXP_INLINE_PROTO_KW():&#160;quaternion.h'],['../vector_8h.html#a70679b95ecd6ab2100dbb16bfa9950a4',1,'_FXP_INLINE_PROTO_KW():&#160;vector.h']]],
  ['_5fqsum',['_QSUM',['../inline_2quaternion_8h.html#a40c4392c08230ca2592d6c739611aaeb',1,'_QSUM():&#160;quaternion.h'],['../inline_2quaternion_8h.html#a40c4392c08230ca2592d6c739611aaeb',1,'_QSUM():&#160;quaternion.h']]],
  ['_5fqtr',['_QTR',['../inline_2quaternion_8h.html#af1306a04d1735816fb622cdb7b1bf34d',1,'quaternion.h']]]
];
