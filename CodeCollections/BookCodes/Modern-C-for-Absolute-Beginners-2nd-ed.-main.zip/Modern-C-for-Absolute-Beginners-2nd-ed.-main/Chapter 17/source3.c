#include <stdio.h>

int main(void)
{
	int x = 123;
	printf("Conditional expression result: %d\n", (x > 10) ? 456 : 789);
}