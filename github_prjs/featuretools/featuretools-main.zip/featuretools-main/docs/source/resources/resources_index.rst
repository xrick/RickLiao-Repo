Resources
---------

Frequently asked questions and additional resources

.. toctree::
   :maxdepth: 1

   transition_to_ft_v1.0
   frequently_asked_questions
   help
   usage_tips/limitations
   usage_tips/glossary
   ecosystem
