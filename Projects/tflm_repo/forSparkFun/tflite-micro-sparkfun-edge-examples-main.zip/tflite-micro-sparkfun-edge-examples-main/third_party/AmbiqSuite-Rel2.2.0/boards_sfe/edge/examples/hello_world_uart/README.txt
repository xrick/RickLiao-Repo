Name:
=====
 hello_world_uart


Description:
============
 A simple "Hello World" example using the UART peripheral.


Purpose:
========
This example prints a "Hello World" message with some device info
over UART at 115200 baud. To see the output of this program, run AMFlash,
and configure the console for UART. The example sleeps after it is done
printing.


******************************************************************************


