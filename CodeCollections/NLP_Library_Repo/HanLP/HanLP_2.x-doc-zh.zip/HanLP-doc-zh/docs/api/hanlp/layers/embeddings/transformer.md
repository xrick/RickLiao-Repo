# transformer


```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.contextual_word_embedding.ContextualWordEmbedding
	:members:

.. autoclass:: hanlp.layers.embeddings.contextual_word_embedding.ContextualWordEmbeddingModule
	:members:

```
