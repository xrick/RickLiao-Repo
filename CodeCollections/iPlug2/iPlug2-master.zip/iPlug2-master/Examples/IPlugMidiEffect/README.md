# IPlugMidiEffect
A MIDI processor plug-in with IGraphics GUI. Only AudioUnits really have a notion of a MIDI effect type
