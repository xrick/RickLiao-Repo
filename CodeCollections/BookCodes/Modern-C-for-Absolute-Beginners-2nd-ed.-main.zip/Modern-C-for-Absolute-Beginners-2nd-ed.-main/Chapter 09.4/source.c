#include <stdio.h>

int main(void)
{
	char myarray[] = "Hello";
	printf("%s", myarray);
}