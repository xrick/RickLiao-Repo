#!/bin/bash

rm -rf exp/*
rm -rf fbank
rm -rf data/*
