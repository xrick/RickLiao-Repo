cfg = dict(
    model='spectformer_s',
    drop_path=0.1,
    clip_grad=None,
    output_dir='checkpoints/spectformer_s',
)