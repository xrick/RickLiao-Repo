# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-07-30 21:03
# 《自然语言处理入门》第 9 章 信息抽取
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
