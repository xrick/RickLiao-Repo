#include <stdio.h>
#include <limits.h>

int main(void)
{
	printf("The minimum value a char can store is: %d\n", CHAR_MIN);
	printf("The maximum value a char can store is: %d\n", CHAR_MAX);
}