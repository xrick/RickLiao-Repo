#include <stdio.h>

int main(void)
{
	printf("Hello World!\nThis is a new line!");
}