#include <stdio.h>

int main(void)
{
	char c = 'A';
	int x = 123;
	double d = 456.789;
	printf("The values are: %c, %d, and %3.2lf\n", c, x, d);
}