# constituency_dataset

```{eval-rst}

.. autoclass:: hanlp.datasets.parsing.loaders.constituency_dataset.ConstituencyDataset
	:members:

```
