# fasttext

```{eval-rst}

.. automodule:: hanlp.pretrained.fasttext
    :members:

```