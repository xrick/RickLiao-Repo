import skbuild
import os

print(os.path.join(os.path.dirname(skbuild.__file__), "resources", "cmake"))

