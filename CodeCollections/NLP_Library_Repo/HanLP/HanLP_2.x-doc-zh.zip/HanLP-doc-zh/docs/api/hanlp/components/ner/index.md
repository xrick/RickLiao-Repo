# ner

Named Entity Recognition.

```{toctree}
transformer_ner
rnn_ner
biaffine_ner
```

