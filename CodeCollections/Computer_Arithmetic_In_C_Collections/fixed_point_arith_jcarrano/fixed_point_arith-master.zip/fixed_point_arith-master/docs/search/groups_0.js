var searchData=
[
  ['comparison_20functions',['Comparison functions',['../group__fxp__cmp.html',1,'']]]
];
