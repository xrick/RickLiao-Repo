#ifndef READ_CSV_H
#define READ_CSV_H


#include <iostream>


void read_csv(float *inp, std::string name);


#endif
