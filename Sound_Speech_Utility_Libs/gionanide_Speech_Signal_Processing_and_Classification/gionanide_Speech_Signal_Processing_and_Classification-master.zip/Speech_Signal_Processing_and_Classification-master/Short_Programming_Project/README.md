University of Groningen
 
 
 Short Programming Project for Gender classification based on voice signals (.wav files)

