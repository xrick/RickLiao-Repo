Here we put the leveldb patch databases.
