    pico_cnn::naive::MatMul *{{identifier}}_layer;
