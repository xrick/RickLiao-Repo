#include <stdio.h>

int main(void)
{
	int mycounter = 0;
	while (mycounter < 5)
	{
		printf("Hello World from a while loop.\n");
		mycounter++;
	}
}