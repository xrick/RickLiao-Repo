#include <stdio.h>

void printMessage(void)
{
	printf("Hello World from a function.\n");
}

int main(void)
{
	printMessage();
}