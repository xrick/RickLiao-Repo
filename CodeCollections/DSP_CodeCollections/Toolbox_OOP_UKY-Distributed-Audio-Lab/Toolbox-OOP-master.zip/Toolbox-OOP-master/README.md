# Toolbox-OOP
Object Oriented implementation for the Array Toolbox. DSP Programming for beamforming and other applications with C++ (and perhaps other languages in the future).
