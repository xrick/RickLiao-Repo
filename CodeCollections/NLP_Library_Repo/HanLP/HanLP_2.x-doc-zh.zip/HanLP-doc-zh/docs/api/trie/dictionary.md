# dictionary

```{eval-rst}
.. currentmodule:: hanlp_trie

.. autoclass:: hanlp_trie.dictionary.DictInterface
	:members:

.. autoclass:: hanlp_trie.dictionary.TrieDict
	:members:
```
