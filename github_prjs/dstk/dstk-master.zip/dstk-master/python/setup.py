from distutils.core import setup
setup(name='dstk',
      version='0.50',
      py_modules=['dstk'],
      author='Pete Warden',
      author_email='pete@petewarden.com',
      url='http://www.datasciencetoolkit.org/'
      )
