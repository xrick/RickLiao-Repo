
    {{identifier}}_layer = new pico_cnn::naive::LRN("{{name}}", 0, pico_cnn::op_type::LRN, {{alpha}}, {{beta}}, {{n}});
