Place the clap-helpers repo from free-audio here

https://github.com/free-audio/clap-helpers

This folder (CLAP_HELPERS) should be the root of the repo
