.. _ref-coordinates:

deeptime.clustering
===================
The *clustering* package contains clustering algorithms that can be used for discretization of time series.

.. automodule:: deeptime.clustering

.. toctree::
   :maxdepth: 1
