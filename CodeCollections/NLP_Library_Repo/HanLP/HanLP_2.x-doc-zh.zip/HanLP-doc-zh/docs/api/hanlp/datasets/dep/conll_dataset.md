# conll

```{eval-rst}
.. currentmodule:: hanlp.datasets.parsing.loaders.conll_dataset 


.. autoclass:: CoNLLParsingDataset
	:members:

```
