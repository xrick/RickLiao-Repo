#include <stdio.h>

int main(void)
{
	printf("Hello World!");
	printf("\nThis is a new line!");
}