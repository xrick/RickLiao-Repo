# IPlug Dependencies & SDKs

To build different formats of plug-in, you need to have the SDKs in place here. Look inside each subfolder for a link showing you where to download the SDK.

You can run the bash shell script ```download-iplug-sdks.sh``` in a terminal (and via git-bash or other unix terminal emulator on Windows) to download some of the publicly available SDKs automatically.