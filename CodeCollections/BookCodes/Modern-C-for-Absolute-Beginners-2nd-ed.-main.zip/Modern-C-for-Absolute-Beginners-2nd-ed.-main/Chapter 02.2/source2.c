int main(void)
{
	/* This is a 
	multi-line comment in C */
}