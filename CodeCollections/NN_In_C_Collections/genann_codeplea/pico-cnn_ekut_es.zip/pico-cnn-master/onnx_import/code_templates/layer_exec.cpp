    {{identifier}}_layer->run({{input_buffer.name}}, {{output_buffer.name}});

