# eos

```{eval-rst}
.. currentmodule:: hanlp.components.eos

.. autoclass:: hanlp.components.eos.ngram.NgramSentenceBoundaryDetector
	:members:

```
