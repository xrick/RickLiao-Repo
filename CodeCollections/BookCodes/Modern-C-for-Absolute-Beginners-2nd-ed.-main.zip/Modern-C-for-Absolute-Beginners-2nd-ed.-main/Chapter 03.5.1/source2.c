#include <stdio.h>

int main(void)
{
	float myfloat;
	myfloat = 123.456f;
	printf("The value of a floating-point variable is: %f", myfloat);
}