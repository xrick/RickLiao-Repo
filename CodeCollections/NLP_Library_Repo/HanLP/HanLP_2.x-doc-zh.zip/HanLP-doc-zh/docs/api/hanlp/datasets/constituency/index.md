# con

Constituency parsing datasets.

```{toctree}
constituency_dataset
resources
```

