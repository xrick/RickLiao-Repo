#include <stdio.h>

void myFunction(void)
{
	printf("Function defined.\n");
}

int main(void)
{
	myFunction();
}