#include <stdio.h>

int main(void)
{
	int x = 1;
	x *= 123;
	printf("%d", x);
}