#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	printf("Included several standard-library headers.\n");
}