# coding=utf-8
# Copyright 2024 The Google Research Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utility to convert saved_model to tflite."""
import sys

import kws_streaming.models.utils as utils
import tensorflow as tf

FLAGS = tf.compat.v1.flags.FLAGS
tf.compat.v1.flags.DEFINE_string('saved_model_path', '',
                                 'Path to input saved_model.')
tf.compat.v1.flags.DEFINE_string('tflite_model_path', '',
                                 'Path to output tflite module.')


def main(unused_argv):
  del unused_argv  # Unused.

  with open(FLAGS.tflite_model_path, 'wb') as fd:
    fd.write(utils.saved_model_to_tflite(FLAGS.saved_model_path))


if __name__ == '__main__':
  FLAGS(sys.argv, known_only=True)
  FLAGS.unparse_flags()

  tf.compat.v1.app.run(main)
