from featuretools.primitives.base import AggregationPrimitive


class Sum(AggregationPrimitive):
    """A primitive that should currently exist for testing."""

    pass
