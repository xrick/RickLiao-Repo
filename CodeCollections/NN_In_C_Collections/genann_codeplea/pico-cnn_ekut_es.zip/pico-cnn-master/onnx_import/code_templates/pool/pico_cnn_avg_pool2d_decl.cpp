    pico_cnn::naive::AveragePooling *{{identifier}}_layer;
