# Component

## Basic Components

### Slider

[API Reference](https://docs.juce.com/master/classSlider.html)

### Label

[API Reference](https://docs.juce.com/master/classLabel.html)

### ComboBox

[API Reference](https://docs.juce.com/master/classComboBox.html)

## Listener

## Timer
