# Examples
- Python: [examples here](python)
- HTTP Server: [examples here](server)
- Rust: [examples here](../mistralrs/examples/)