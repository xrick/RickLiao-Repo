# Travis CI

- basics
- install dependencies
  - Linux fake Xorg
- platform matrix
- push to gh-pages
- run pluginval
- full example
