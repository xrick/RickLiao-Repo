.. _api:

.. module:: scaper

Core functionality
------------------
.. automodule:: scaper.core
    :members:

.. automodule:: scaper.core.Scaper
    :members: