/*
 * <summary></summary>
 * <author>He Han</author>
 * <email>me@hankcs.com</email>
 * <create-date>16/3/18 AM11:53</create-date>
 *
 * <copyright file="package-info.java" company="码农场">
 * Copyright (c) 2008-2016, 码农场. All Right Reserved, http://www.hankcs.com/
 * This source is subject to Hankcs. Please contact Hankcs to get more information.
 * </copyright>
 */
/**
 * 一些常用的配置好的静态分词器,其中一些具备特殊的预处理功能<br>
 *     可供用户参考以实现自己的预处理逻辑.
 */
package com.hankcs.hanlp.tokenizer;