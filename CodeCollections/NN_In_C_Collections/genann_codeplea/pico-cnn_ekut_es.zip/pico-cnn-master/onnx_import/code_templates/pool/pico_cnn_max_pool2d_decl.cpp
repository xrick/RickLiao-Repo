    pico_cnn::naive::MaxPooling *{{identifier}}_layer;
