int main(void)
{
	char mychar = 97;
}