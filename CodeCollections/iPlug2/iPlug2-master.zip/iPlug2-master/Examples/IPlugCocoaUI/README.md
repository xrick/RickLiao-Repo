# IPlugCocoaUI
A basic macOS and iOS only plug-in using Cocoa / UIKit and AppKit in order to implement the GUI