# csignal
Slowly built library of Digital Signal Processing Commonly used Transforms for Spectral Analysis, and pseudo - time-spectral Analysis.  implementations demonstrating the capabilities of Audio Signal Processing, Filter Design, Data Transformations, and Audio Signal Processing. 

#REFERENCES: https://ccrma.stanford.edu/software/stk/download.html
https://github.com/FFTW/fftw3.git
