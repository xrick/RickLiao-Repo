cfg = dict(
    model='spectformer_b',
    drop_path=0.1,
    clip_grad=None,
    output_dir='checkpoints/spectformer_b',
)