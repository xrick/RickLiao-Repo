#ifndef MYHEADERFILE_H
#define MYHEADERFILE_H

#define MYMACRO 123

#endif