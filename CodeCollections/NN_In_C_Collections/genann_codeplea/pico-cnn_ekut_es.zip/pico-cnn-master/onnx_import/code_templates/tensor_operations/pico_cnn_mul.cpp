
    {{input_buffer.name}}->mul_with_factor({{output_buffer.name}}, {{factor}});
