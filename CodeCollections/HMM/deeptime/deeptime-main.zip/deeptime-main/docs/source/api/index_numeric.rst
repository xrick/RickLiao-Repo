.. _ref-numeric:

deeptime.numeric
================
The *numeric* package contains numerical utilities.

.. automodule:: deeptime.numeric

.. toctree::
   :maxdepth: 1
