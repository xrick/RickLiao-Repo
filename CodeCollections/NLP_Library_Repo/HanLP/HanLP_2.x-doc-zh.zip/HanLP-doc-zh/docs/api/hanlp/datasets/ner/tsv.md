# tsv

```{eval-rst}
.. currentmodule:: hanlp.datasets.ner.loaders.tsv

.. autoclass:: TSVTaggingDataset
	:members:

```
