# eos

```{eval-rst}
.. currentmodule:: hanlp.datasets.eos.eos

.. autoclass:: SentenceBoundaryDetectionDataset
	:members:

```
