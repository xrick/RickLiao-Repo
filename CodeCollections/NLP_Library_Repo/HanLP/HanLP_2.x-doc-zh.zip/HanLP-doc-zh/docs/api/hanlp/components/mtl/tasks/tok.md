# tok

Tokenization.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.tok.tag_tok.TaggingTokenization
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
