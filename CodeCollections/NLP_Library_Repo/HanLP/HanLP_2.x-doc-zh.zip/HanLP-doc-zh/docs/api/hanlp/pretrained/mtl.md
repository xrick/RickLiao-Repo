# mtl

```{eval-rst}

.. automodule:: hanlp.pretrained.mtl
    :members:

```