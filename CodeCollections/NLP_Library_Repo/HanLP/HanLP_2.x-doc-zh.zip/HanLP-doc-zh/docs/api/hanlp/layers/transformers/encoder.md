# encoder


```{eval-rst}

.. autoclass:: hanlp.layers.transformers.encoder.TransformerEncoder
	:members:

```
