.. _api/main:

hanlp
==========

.. currentmodule:: hanlp

.. autofunction:: load

.. autofunction:: pipeline