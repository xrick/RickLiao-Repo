#include <stdio.h>

int main(void)
{
	int mycounter = 0;
	do
	{
		printf("Hello World from a do-while loop.\n");
		mycounter++;
	} while (mycounter < 5);
}