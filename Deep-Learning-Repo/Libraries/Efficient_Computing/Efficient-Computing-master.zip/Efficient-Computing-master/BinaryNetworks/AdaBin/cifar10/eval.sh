python3 main.py --arch resnet20_1w1a --data /cache/ \
                --save-dir ./checkpoints/resnet20_1w1a/ \
                --pretrained ./checkpoints/resnet20_1w1a/model.th \
                --gpu-id 0 --print-freq 100 --evaluate