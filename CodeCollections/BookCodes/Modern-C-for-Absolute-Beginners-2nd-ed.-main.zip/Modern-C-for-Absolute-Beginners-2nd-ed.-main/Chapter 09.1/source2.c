int main(void)
{
	float myarr[5];
}