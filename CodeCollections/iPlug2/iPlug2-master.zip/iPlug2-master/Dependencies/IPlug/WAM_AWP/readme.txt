Place the AudioWorklet Polyfill (iPlug2 fork) code here 

https://github.com/iPlug2/audioworklet-polyfill

so it looks like this...

Dependencies/IPlug/WAM_AWP/README.md
Dependencies/IPlug/WAM_AWP/audioworker.js
Dependencies/IPlug/WAM_AWP/audioworklet.js

More info:

https://www.webaudiomodules.org/blog/audioworklet_polyfill/

