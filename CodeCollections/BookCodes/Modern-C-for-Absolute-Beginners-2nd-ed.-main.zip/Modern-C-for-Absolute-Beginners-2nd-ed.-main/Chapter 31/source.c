#include <stdio.h>
#include "myutils.h"

int main(void)
{
	myFunction();
}