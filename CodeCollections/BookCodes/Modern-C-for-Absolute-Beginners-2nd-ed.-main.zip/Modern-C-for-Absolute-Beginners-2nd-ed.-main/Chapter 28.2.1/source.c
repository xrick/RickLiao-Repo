#include <stdio.h>

int main(void)
{
	printf("This message ends with a new-line character.\n");
}