#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
The [semantic] version of the package.
"""

__VERSION__ = "4.7.2"
