# tok

Tokenization datasets.

```{toctree}
txt
mcws_dataset
resources
```

