# `mistralrs-vision`

This crate provides vision utilities for mistral.rs inspired by torchvision.

Documentation: https://ericlbuehler.github.io/mistral.rs/mistralrs_vision/index.html