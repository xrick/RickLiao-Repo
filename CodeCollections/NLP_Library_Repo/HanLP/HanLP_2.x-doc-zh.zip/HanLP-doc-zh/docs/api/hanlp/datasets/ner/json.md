# json

```{eval-rst}
.. currentmodule:: hanlp.datasets.ner.loaders.json_ner

.. autoclass:: JsonNERDataset
	:members:

```
