#!/usr/bin/env sh

/home/dongxuanyi/code/binary/caffe-binary/build/tools/caffe train \
    --solver=/home/dongxuanyi/code/binary/caffe-binary/models/bvlc_reference_caffenet/solver.prototxt
