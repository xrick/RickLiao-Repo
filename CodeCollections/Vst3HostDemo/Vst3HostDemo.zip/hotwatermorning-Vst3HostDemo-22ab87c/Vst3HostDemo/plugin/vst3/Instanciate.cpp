// VST3 SDK中のサンプル実装などを取り込み

#include "public.sdk/source/common/memorystream.cpp"
#include "public.sdk/source/vst/hosting/eventlist.cpp"
#include "public.sdk/source/vst/hosting/hostclasses.cpp"
#include "public.sdk/source/vst/hosting/parameterchanges.cpp"
