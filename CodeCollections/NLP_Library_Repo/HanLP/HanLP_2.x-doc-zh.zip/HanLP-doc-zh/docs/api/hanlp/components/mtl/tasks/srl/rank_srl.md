# rank_srl

Span Ranking Semantic Role Labeling.

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.tasks.srl.rank_srl.SpanRankingSemanticRoleLabeling
	:members:
	:exclude-members: execute_training_loop, fit_dataloader

```
