#!/bin/bash

export PATH="$PATH:src/featbin/"
