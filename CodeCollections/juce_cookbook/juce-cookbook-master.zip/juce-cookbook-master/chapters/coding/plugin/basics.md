# Plugin Basics

- AudioProcessor
- Plug-ins
  - VST/AU
