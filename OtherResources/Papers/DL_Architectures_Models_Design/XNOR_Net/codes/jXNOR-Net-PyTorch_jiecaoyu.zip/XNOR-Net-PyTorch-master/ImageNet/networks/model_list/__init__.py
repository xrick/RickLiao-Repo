from alexnet import alexnet
