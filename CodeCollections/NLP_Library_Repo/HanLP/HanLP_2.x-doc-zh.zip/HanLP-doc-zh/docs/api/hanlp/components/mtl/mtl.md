# MultiTaskLearning

```{eval-rst}
.. currentmodule:: hanlp.components.mtl

.. autoclass:: hanlp.components.mtl.multi_task_learning.MultiTaskLearning
	:members:
	:special-members:
	:exclude-members: __init__, __repr__

```
