utils
=====

.. automodule:: libf0.utils
    :members:
    :undoc-members:
