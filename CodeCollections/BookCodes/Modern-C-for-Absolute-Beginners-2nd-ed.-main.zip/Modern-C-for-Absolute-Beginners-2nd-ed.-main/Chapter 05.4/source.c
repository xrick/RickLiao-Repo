#include <stdio.h>

int main(void)
{
	int x = 0;
	x += 123;
	printf("%d", x);
}