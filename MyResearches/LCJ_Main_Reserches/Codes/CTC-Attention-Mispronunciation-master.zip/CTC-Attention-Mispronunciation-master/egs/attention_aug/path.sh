KALDI_ROOT=/home/ljh/kaldi

. $KALDI_ROOT/tools/config/common_path.sh
export LC_ALL=C
