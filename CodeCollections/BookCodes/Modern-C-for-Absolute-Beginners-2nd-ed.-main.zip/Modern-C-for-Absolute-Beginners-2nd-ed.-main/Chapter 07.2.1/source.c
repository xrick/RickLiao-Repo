#include <stdio.h>

int main(void)
{
	int x = 123;
	if (x < 150)
	{
		printf("The x is less than 150.\n");
		printf("This is a second statement.\n");
	}
}