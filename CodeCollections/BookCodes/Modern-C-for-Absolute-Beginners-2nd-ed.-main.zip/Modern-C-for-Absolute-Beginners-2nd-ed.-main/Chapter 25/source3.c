#include <stdio.h>

int main(void)
{
	char *p = "Hello World!";
	printf("String constant: %s\n", p);
}