

class DefaultCallback():

    pass