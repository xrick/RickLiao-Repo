# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-07-01 19:14
# 《自然语言处理入门》第 6 章 条件随机场与序列标注
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
