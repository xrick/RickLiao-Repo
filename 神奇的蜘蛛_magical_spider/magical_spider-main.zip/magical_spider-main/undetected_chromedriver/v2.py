# for backward compatibility
import sys

sys.modules[__name__] = sys.modules[__package__]
