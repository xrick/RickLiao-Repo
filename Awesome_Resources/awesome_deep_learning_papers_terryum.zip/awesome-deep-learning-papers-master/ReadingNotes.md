


## Robotics
- [Learning Inverse Dynamics Models in O(n) time with LSTM networks](#learning-inverse-dynamics-models-in-on-time-with-lstm-networks) (2017), Elmar Rueckert, Moritz Nakatenus, Samuele Tosatto, and Jan Peters, Humanoid 2017. (2017/10/03 read).




### Learning Inverse Dynamics Models in O(n) time with LSTM networks
* Limitation of the current methods
  * GPR (![Eq:On3])and LWR is not scalable
* Contribution of this paper
  * 

**Bibtex**: to appear

$$
o(n^{3})
$$

[Eq:On3]: http://rogercortesi.com/eqn/tempimagedir/eqn8190.png
