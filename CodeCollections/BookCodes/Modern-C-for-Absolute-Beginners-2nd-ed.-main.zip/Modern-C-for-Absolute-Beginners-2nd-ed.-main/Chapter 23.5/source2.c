#include <stdio.h>

int main(void)
{
	printf("This source code file is called: %s\n", __FILE__);
}