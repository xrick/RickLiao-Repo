import sysconfig
print(sysconfig.get_paths()["purelib"])
