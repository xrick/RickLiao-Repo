from .librispeech import LibriSpeechDataModule
from .sol import SOLDataModule