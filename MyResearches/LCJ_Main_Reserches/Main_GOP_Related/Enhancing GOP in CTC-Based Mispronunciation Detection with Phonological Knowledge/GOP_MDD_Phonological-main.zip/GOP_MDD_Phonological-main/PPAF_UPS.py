#!/usr/bin/env python3
"""
Goodness of Pronunciation (GOP) Calculation Pipeline using CTC loss and substitution mappings
"""

import csv
import logging
from pathlib import Path
from typing import Dict, List, Tuple

import torch
import numpy as np
from datasets import load_from_disk
from tqdm import tqdm
from transformers import Wav2Vec2CTCTokenizer, Wav2Vec2Processor, Wav2Vec2ForCTC

# Configuration Constants
MODEL_PATH = "facebook/wav2vec2-xlsr-53-espeak-cv-ft"
CACHE_DIR = Path("/cache_dir")
DATASET_PATH = Path("/data/spo762/so_everything_cmu_ipa")
OUTPUT_CSV = Path("ppaf_ups.csv")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


common_phones = [ "n", "t", "s", "k", "d", "m", "z", "ɾ", "f", "ð",
                  "v", "b", "ɹ", "ʁ", "r", "w", "h", "ŋ", "ʃ", "θ", 
                  "ə", "a", "i", "o", "ɪ", "ɛ", "ɐ", "u", "e", "ʌ",
                  "ʊ", "æ", "ɔ", "ɑː", "aɪ", "eɪ", "oʊ", "aʊ", "iː", 
                  "uː", "ð", "β", "ɚ", "ᵻ" ]


def ctc_loss(params, seq, blank=0):
    """
    CTC loss function.
    params - n x m matrix of n-D probability distributions(softmax output) over m frames.
    seq - sequence of phone id's for given example.
    Returns objective, alphas and betas.
    """
    seqLen = seq.shape[0] # Length of label sequence (# phones)
    numphones = params.shape[0] # Number of labels
    L = 2*seqLen + 1 # Length of label sequence with blanks
    T = params.shape[1] # Length of utterance (time)

    alphas = torch.zeros((L,T)).double()
    alpha_bar = torch.zeros(T).double()

    # Initialize alphas and forward pass 
    alphas[0,0] = params[blank,0]
    alphas[1,0] = params[seq[0],0]
    alpha_bar[0] = torch.sum(alphas[:,0])
    alphas[:,0] = alphas[:,0] /  alpha_bar[0]

    for t in range(1,T):
        start = max(0,L-2*(T-t)) 
        end = min(2*t+2,L)
        for s in range(start,L):
            l = int((s-1)/2)
            # blank
            if s%2 == 0:
                if s==0:
                    alphas[s,t] = alphas[s,t-1] * params[blank,t]
                else:
                    alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1]) * params[blank,t]
            # same label twice
            elif s == 1 or seq[l] == seq[l-1]:
                alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1]) * params[seq[l],t]
            else:
                alphas[s,t] = (alphas[s,t-1] + alphas[s-1,t-1] + alphas[s-2,t-1]) \
                    * params[seq[l],t]
        alpha_bar[t] = torch.sum(alphas[:,t])
        alphas[:,t] = alphas[:,t] / alpha_bar[t]
    
    llForward = torch.log(alpha_bar).sum()   
	
    return -llForward

def initialize_components() -> Tuple[Wav2Vec2Processor, Wav2Vec2CTCTokenizer, Wav2Vec2ForCTC]:
    """Initialize model components with proper caching and configuration."""
    processor = Wav2Vec2Processor.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    model = Wav2Vec2ForCTC.from_pretrained(MODEL_PATH, cache_dir=CACHE_DIR)
    model.eval()
    return processor, tokenizer, model

def create_confusion_id_map(tokenizer: Wav2Vec2CTCTokenizer) -> Dict[int, List[int]]:
    """Convert phoneme symbols to model token IDs with validation."""
    confusion_map = {}
    for phoneme, confusions in PHONEME_CONFUSION_MAP.items():
        try:
            phoneme_id = tokenizer._convert_token_to_id(phoneme)
            confusion_ids = [tokenizer._convert_token_to_id(c) for c in confusions]
            confusion_map[phoneme_id] = confusion_ids
        except KeyError as e:
            logger.warning(f"Skipping phoneme {phoneme}: {str(e)}")
    return confusion_map

def select_subset(dataset, sample_size: int = 2):
    """Select a random subset of the dataset for testing."""
    return dataset.shuffle().select(range(sample_size))

def process_utterance(datum, processor, tokenizer, model, common_phones):
    """Process a single utterance and calculate GOP scores."""
    try:
        # Audio processing
        input_values = processor(
            datum["audio"]["array"],
            return_tensors="pt",
            sampling_rate=16000
        ).input_values
        
        # Convert transcription to token IDs
        labels = torch.tensor(
            tokenizer.convert_tokens_to_ids(datum["cmu_ipa_phonetic_transcription"]),
            dtype=torch.int32
        )

        token_ids = [tokenizer._convert_token_to_id(phone) for phone in common_phones]

        with torch.no_grad():
            # Calculate original loss using CTC loss
            return_dict = model(input_values, labels=labels)
            logits = return_dict["logits"].squeeze(0)
            post_mat = logits.softmax(dim=-1).type(torch.float64)
            original_loss = ctc_loss(post_mat.transpose(0, 1), labels, blank=0).item()
        
            # Prepare perturbations
            per_phoneme_perturbations = {}
            for idx, phone_id in enumerate(labels.tolist()):
                phoneme_perturbations = []

                # Substitute the phoneme with every token in the vocabulary
                for sub_id in token_ids:
                    if sub_id != phone_id:  # Avoid substituting with the same phoneme
                        new_labels = labels.clone()
                        new_labels[idx] = sub_id
                        phoneme_perturbations.append(new_labels)

                # Deletion for this phoneme
                if labels.shape[0] > 1:
                    deleted_labels = torch.cat([labels[:idx], labels[idx+1:]])
                    phoneme_perturbations.append(deleted_labels)

                per_phoneme_perturbations[idx] = phoneme_perturbations

            # Calculate losses PER PHONEME
            results = []
            for idx, phone in enumerate(datum["cmu_ipa_phonetic_transcription"]):
                perturb_losses = []

                # Process perturbations for this specific phoneme
                for perturbed_labels in per_phoneme_perturbations.get(idx, []):
                    try:
                        # Calculate loss for perturbed labels
                        perturbed_loss = ctc_loss(post_mat.transpose(0, 1), perturbed_labels, blank=0).item()
                        perturb_losses.append(perturbed_loss)
                    except Exception as e:
                        logger.debug(f"Skipping invalid perturbation: {str(e)}")

                # Calculate GOP for this phoneme
                if perturb_losses:
                    best_perturb_loss = min(perturb_losses)
                    gop_score =   best_perturb_loss - original_loss
                    optimality = "optimal" if gop_score >= 0 else "suboptimal"
                else:
                    gop_score = None
                    optimality = "unknown"

                results.append({
                    "uttid": Path(datum["uttid"]).name,
                    "actual_phoneme": phone,
                    "GOP": gop_score,
                    "optimality": optimality,
                    "mispronounced": datum.get("mispronounced", False)
                })

        return results

    except Exception as e:
        logger.error(f"Error processing {datum.get('audio', {}).get('path', 'unknown')}: {str(e)}")
        return []


def main(test_mode: bool = True):
    """Main execution pipeline."""
    processor, tokenizer, model = initialize_components()
    
    # Load and prepare dataset
    dataset = load_from_disk(DATASET_PATH)
    #dataset = full_dataset.map(lambda x: {
    #    'transcription': x['phonetic_transcription_ipa'].split()
    #}).remove_columns(['phonetic_transcription_ipa'])
    
    # Select subset for testing
    processed_dataset = select_subset(dataset, 2) if test_mode else dataset
    
    # Process dataset and write results
    with open(OUTPUT_CSV, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["uttid", "actual_phoneme", "GOP", "optimality", "mispronounced"])
        writer.writeheader()
        
        for datum in tqdm(processed_dataset, desc="Processing utterances"):
            results = process_utterance(datum, processor, tokenizer, model,common_phones=common_phones)
            for result in results:
                writer.writerow(result)

if __name__ == "__main__":
    # Run in test mode (small subset), set test_mode=False for full run
    main(test_mode=False)
