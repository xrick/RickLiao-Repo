# transform

```{eval-rst}
.. currentmodule:: hanlp.common

.. autoclass:: hanlp.common.transform.VocabDict
	:members:

```
