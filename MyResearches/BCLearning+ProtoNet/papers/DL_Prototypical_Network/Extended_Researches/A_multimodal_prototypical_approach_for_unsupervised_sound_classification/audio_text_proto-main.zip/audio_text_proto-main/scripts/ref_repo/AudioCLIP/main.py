#!/usr/bin/env python3.7

import ignite_trainer as it


def main():
    it.main()


if __name__ == '__main__':
    main()
