var searchData=
[
  ['frac_5fbase',['frac_base',['../group__fxp__class.html#ga55909e6de29b4431bbeeec814500d365',1,'types.h']]],
  ['frac_5fs16',['frac_s16',['../group__fxp__width.html#ga2cd73c4d4408a4acf3d6b5d5ee589a12',1,'types.h']]],
  ['frac_5fs32',['frac_s32',['../group__fxp__width.html#ga9cece7f292e931ca324aec8e87e1eaac',1,'types.h']]]
];
