
    {{input_buffer.name}}->copy_data_into({{output_buffer.name}});
