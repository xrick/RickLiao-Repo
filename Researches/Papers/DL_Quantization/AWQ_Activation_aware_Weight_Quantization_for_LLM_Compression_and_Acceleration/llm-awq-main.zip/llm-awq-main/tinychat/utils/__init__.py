import tinychat.utils.constants as constants

constants.init()
