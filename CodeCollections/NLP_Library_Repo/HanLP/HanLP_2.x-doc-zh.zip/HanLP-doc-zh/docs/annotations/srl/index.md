# Semantic Role Labeling

## Chinese
```{toctree}
cpb
```

## English
```{toctree}
propbank
```

