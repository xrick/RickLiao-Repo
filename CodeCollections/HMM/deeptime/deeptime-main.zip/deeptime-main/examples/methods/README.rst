.. _method_examples:

General examples
----------------

Short examples for some of the methods.
