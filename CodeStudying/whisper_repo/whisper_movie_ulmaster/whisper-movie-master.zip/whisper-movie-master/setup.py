from setuptools import setup

setup(
    name="nni_amlt",
    description="Amulet toolkit extension of NNI.",
    version="0.1",
    install_requires=["requests", "pysrt"],
    packages=["whispermovie"],
)
