.. _legal-notes-label:

=======
Imprint
=======

Imprint according to § 6 TDG and § 10 Mediendienstestaatsvertrag

Institution:
Freie Universität Berlin
Arnimallee 6, 14195 Berlin

Represented by:

Prof. Dr. Frank Noé

Contact:
+49 30 838 75354
frank.noe@fu-berlin.de

Disclaimer

Online contents:

The Webteam of “deeptime” reserves the right not to be responsible for the topicality, correctness, completeness
or quality of the information provided. Liability claims regarding damage caused by the use of any information provided,
including any kind of information which is incomplete or incorrect, will therefore be rejected.
All offers are not-binding and without obligation. Parts of the pages or the complete publication including
all offers and information might be extended, changed or partly or completely deleted by the Webteam without separate announcement.

Referrals and links:

The Webteam is not responsible for any contents linked or referred to from his pages – unless the Webteam has
full knowlegde of illegal contents and would be able to prevent the visitors of the Research Group site from
viewing those pages. If any damage occurs by the use of information presented there, only the author of the respective
pages might be liable, not the one who has linked to these pages. Furthermore the Webteam is not liable for any postings
or messages published by users of discussion boards, guestbooks or mailinglists provided on their page.

Copyright:

The Webteam intended not to use any copyrighted material for the publication or, if not possible, to indicate the
copyright of the respective object.
The copyright for any material created by the Webteam is reserved. Any duplication or use of such diagrams,
sounds or texts in other electronic or printed publications is not permitted without the Webteam’s agreement.

Legal validity of this disclaimer:
This disclaimer is to be regarded as part of the internet publication which you were referred from.
If sections or individual formulations of this text are not legal or correct, the content or validity of the other
parts remain uninfluenced by this fact.
The text of this disclaimer is based on the services of www.disclaimer.de
