_base_ = './i_base.py'
item_cfg = {'b': 2}
item6 = {'cfg': item_cfg}
