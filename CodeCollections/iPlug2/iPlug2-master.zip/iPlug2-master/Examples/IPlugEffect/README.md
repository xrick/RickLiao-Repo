# IPlugEffect
A basic volume control effect plug-in with IGraphics GUI
