clear
python3 train.py --data=/data/imagenet | tee -a log/log.txt
