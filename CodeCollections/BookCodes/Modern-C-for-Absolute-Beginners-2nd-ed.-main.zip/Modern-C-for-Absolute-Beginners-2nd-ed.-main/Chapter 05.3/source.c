#include <stdio.h>

int main(void)
{
	int x;
	x = 123;
	printf("%d", x);
}