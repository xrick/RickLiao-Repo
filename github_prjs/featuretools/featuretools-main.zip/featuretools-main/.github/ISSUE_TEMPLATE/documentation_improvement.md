---
name: Documentation Improvement
about: Suggest an idea for improving the documentation
title: ''
labels: 'documentation'
assignees: ''

---

[a description of what documentation you believe needs to be fixed/improved]
