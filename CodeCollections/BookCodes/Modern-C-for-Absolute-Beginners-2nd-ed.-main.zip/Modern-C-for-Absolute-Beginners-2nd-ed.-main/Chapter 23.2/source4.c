#include <stdio.h>

#define MY_NEW_LINE '\n'
#define MY_SPACE ' '

int main(void)
{
	printf("This example%cuses %cmacros.", MY_SPACE, MY_NEW_LINE);
}