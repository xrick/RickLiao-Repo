# word2vec

```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.word2vec.Word2VecEmbedding
	:members:

.. autoclass:: hanlp.layers.embeddings.word2vec.Word2VecEmbeddingModule
	:members:

```
