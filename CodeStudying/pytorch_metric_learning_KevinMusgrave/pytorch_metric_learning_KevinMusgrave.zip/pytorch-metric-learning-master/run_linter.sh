flake8 src tests --count --show-source --statistics
nbqa flake8 examples --count --show-source --statistics