#include <stdio.h>

int main(void)
{
	unsigned long y;
	y = 123456789ul;
	printf("The value of an unsigned long variable is: %lu\n", y);
}