# Debugging

- AudioPluginHost
  - IDE Integration
