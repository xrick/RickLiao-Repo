# taggers

Taggers.

```{toctree}
transformer_tagger
rnn_tagger
```

