#ifndef PARSER_H
#define PARSER_H

int parse_P();
int parse_E();
int parse_E_prime();
int parse_T();
int parse_T_prime();
int parse_F();

#endif
