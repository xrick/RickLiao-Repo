
    {{identifier}}_layer = new pico_cnn::naive::MatMul("{{name}}", 0, pico_cnn::op_type::MatMul, {{weight_buffer.name}});
