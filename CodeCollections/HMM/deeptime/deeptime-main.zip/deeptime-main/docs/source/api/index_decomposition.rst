.. _ref-decomposition:

deeptime.decomposition
======================

The *decomposition* package contains algorithms which can be used to project data onto dominant slow processes.

.. automodule:: deeptime.decomposition

.. toctree::
   :maxdepth: 1
