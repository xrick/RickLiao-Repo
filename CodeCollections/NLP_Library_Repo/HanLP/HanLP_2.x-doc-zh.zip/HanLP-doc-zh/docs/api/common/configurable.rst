.. _api/configurable:

configurable
====================


.. autoclass:: hanlp_common.configurable.Configurable
	:members:

.. autoclass:: hanlp_common.configurable.AutoConfigurable
	:members:
