#include <stdio.h>

int main(void)
{
	for (int i = 0; i < 5; ++i)
	{
		printf("Hello World from a for loop.\n");
	}
}