source <env_name>/bin/activate

pip install torch
pip install torchvision
pip install numpy
pip install scipy
pip install matplotlib
pip install scikit-image
pip install tqdm