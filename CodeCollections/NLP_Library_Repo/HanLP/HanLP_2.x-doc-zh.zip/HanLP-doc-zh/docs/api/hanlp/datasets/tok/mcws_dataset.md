# mcws_dataset

```{eval-rst}
.. currentmodule:: hanlp.datasets.tokenization.loaders.multi_criteria_cws.mcws_dataset

.. autoclass:: MultiCriteriaTextTokenizingDataset
	:members:

```
