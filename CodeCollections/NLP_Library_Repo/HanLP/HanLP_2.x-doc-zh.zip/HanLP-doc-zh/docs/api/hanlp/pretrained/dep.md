# dep

```{eval-rst}

.. automodule:: hanlp.pretrained.dep
    :members:

```