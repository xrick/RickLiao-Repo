#include <stdio.h>

int main(void)
{
	char* p = "Hello World!";
	printf("%s", p);
}