Use this directory to save each of your checkpoints. 

In general the file name should be: 
```
modelname_pruner_seed.t7
```

e.g. a ResNet-18 pruned with L1 pruning, seeded with 1 should be saved as:

```
resnet18_l1_1.t7
```