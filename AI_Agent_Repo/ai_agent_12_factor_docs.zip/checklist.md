
### 🧠 12-Factor AI Agent Engineering Checklist

| # | 原則 | 檢查項目 | 狀態 |
|:-:|:--|:--|:--|
| **1. Codebase** | 單一版本控制系統應包含所有 Agent 程式與 prompt 資源 | ☐ |
|  | 是否使用單一 Git Repo / Monorepo 管理所有 Agent 元件？ | ☐ |
|  | 是否同步管理 prompt 資料夾（system / task / example）？ | ☐ |
| **2. Config** | 所有設定外部化，避免硬編碼於程式中 | ☐ |
|  | LLM provider, model, temperature, memory config 是否以 ENV / YAML 定義？ | ☐ |
|  | 不同環境 (dev/stage/prod) 是否擁有獨立配置？ | ☐ |
| **3. Prompts** | Prompt 應可版本控管、測試、封裝 | ☐ |
|  | Prompt 是否存放於 versioned prompt registry？ | ☐ |
|  | 是否有自動化 prompt 測試 (prompt-tests/*.json)？ | ☐ |
| **4. Context** | Agent 核心應保持無狀態，狀態交由 Memory Service 管理 | ☐ |
|  | 是否將對話記憶存放於 Milvus/Faiss？ | ☐ |
|  | 是否使用 Redis/SQLite 管理 session？ | ☐ |
| **5. Dependencies** | 所有依賴須明確聲明並隔離 | ☐ |
|  | 是否以 requirements.txt / pyproject.toml 定義依賴？ | ☐ |
|  | 是否明確定義模型與工具依賴？ | ☐ |
| **6. Services** | 代理應由多個可組合 micro-skills 構成 | ☐ |
|  | 是否將 Retrieval / Summarizer / Matcher 拆成獨立服務？ | ☐ |
|  | 是否有統一的 Service Registry？ | ☐ |
| **7. Concurrency** | 代理應支援並行處理任務 | ☐ |
|  | 是否使用 asyncio 或 actor 模型？ | ☐ |
|  | 是否具備非同步任務排程？ | ☐ |
| **8. Port Binding** | 代理應自我封裝並暴露標準介面 | ☐ |
|  | 是否提供 REST / OpenAI-compatible API？ | ☐ |
|  | 是否支援 WebSocket 即時互動？ | ☐ |
| **9. Disposability** | 代理應可快速啟動與關閉 | ☐ |
|  | 是否支援容器化（Docker Compose / K8s）？ | ☐ |
|  | 是否實現冷啟與快照機制？ | ☐ |
| **10. Dev/Prod Parity** | 開發與生產環境應具備一致性與可重現性 | ☐ |
|  | 是否能模擬 LLM 決策路徑？ | ☐ |
|  | 是否提供推理 replay 工具？ | ☐ |
| **11. Telemetry** | 應具備可觀測性與回饋學習能力 | ☐ |
|  | 是否集中收集日誌、追蹤與錯誤？ | ☐ |
|  | 是否建立人類回饋機制 (RLAIF loop)？ | ☐ |
| **12. Evolution** | 代理應具備自我演化與自動部署能力 | ☐ |
|  | 是否有 CI/CD pipeline 驗證 prompt 更新？ | ☐ |
|  | 是否有 A/B Test 流程評估模型行為變化？ | ☐ |
