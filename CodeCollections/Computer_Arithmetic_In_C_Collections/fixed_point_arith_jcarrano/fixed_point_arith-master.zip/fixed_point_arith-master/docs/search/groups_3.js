var searchData=
[
  ['macros',['Macros',['../group__fxp__macros.html',1,'']]],
  ['mfrac_20limits',['MFRAC Limits',['../group__mfrac__limits.html',1,'']]]
];
