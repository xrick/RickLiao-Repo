var searchData=
[
  ['unit_5fdquat',['UNIT_DQUAT',['../group__fxp__quat.html#gab4d81e98ed00132d4b660cc347580f45',1,'quaternion_types.h']]],
  ['unit_5fquat',['UNIT_QUAT',['../group__fxp__quat.html#gac3e9b61bfaa0530cf7aaec3814815505',1,'quaternion_types.h']]]
];
