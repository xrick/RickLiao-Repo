# embedding


```{eval-rst}

.. autoclass:: hanlp.layers.embeddings.embedding.Embedding
	:members:

.. autoclass:: hanlp.layers.embeddings.embedding.ConcatModuleList
	:members:

.. autoclass:: hanlp.layers.embeddings.embedding.EmbeddingList
	:members:

```
