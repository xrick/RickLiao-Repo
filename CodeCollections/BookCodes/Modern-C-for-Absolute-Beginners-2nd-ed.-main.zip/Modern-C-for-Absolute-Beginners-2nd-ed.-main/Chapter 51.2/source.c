#include <stdio.h>
#include <float.h>

int main(void)
{
	printf("The minimum, positive value for a float is: %e\n", FLT_MIN);
}