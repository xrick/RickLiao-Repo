# Environment

Env variables to adjust the project.

## CHROME_URL

You can set the chrome URL to connect remotely.

```sh
CHROME_URL=http://localhost:9222
```
