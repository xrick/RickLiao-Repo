from ._hubert_loss import hubert_loss

__all__ = [
    "hubert_loss",
    "wav2vec2_loss",
]
