# -*- coding:utf-8 -*-
# Author: hankcs
# Date: 2020-11-26 16:07
ONTONOTES5_HOME = 'https://catalog.ldc.upenn.edu/LDC2013T19/LDC2013T19.tgz#/ontonotes-release-5.0/data/'
CONLL12_HOME = ONTONOTES5_HOME + '../conll-2012/'
