#include <stdio.h>

int main(void)
{
	double d = 123.456;
	printf("%3.2lf\n", d);
}