#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# CREATED: 10/13/16 7:08 PM by Justin Salamon <justin.salamon@nyu.edu>

'''Warning classes for Scaper'''


class ScaperWarning(Warning):
    '''The root Scaper warning class'''

    pass
