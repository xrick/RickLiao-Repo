from .config import is_list, is_dict, to_list, to_dict, get_class, instantiate
