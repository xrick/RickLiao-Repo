# -*- coding:utf-8 -*-
# Author：hankcs
# Date: 2018-06-05 18:03
# 《自然语言处理入门》第 3 章 二元语法与中文分词
# 配套书籍：http://nlp.hankcs.com/book.php
# 讨论答疑：https://bbs.hankcs.com/
