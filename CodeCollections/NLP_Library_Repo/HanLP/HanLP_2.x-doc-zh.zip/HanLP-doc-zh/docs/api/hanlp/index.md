# hanlp

Core APIs for `hanlp`.

```{toctree}
hanlp
common/index
components/index
pretrained/index
datasets/index
utils/index
layers/index
```