#include <stdio.h>

int main(void)
{
	char *p = "This is a character array.";
	printf("The result is: %s", p);
}