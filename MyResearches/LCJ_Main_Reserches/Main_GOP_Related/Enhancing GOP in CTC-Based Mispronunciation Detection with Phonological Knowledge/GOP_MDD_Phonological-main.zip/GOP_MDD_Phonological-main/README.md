# GOP_MDD_Phonological
Code for interspeech paper 2025:  Enhancing GOP in CTC-Based Mispronunciation Detection with Phonological Knowledge


This repository contains resources for the paper:
 
**"Enhancing GOP in CTC-Based Mispronunciation Detection with Phonological Knowledge"**  
by Aditya Kamlesh Parikh, Cristian Tejedor-Garcia, Catia Cucchiarini, and Helmer Strik
 
📣 _Accepted at [Interspeech 2025](https://www.interspeech2025.org)!_
 
## Citation
 
If you use this work, please cite it as:
 
### 📄 LaTeX (BibTeX)
```bibtex
@inproceedings{parikh25_interspeech,
  title     = {{Enhancing GOP in CTC-Based Mispronunciation Detection with Phonological Knowledge}},
  author    = {Aditya Kamlesh Parikh and Cristian Tejedor-Garcia and Catia Cucchiarini and Helmer Strik},
  year      = {2025},
  booktitle = {{Interspeech 2025}},
  pages     = {5068--5072},
  doi       = {10.21437/Interspeech.2025-829},
  issn      = {2958-1796},
}
```

## 📚 APA
Parikh, A.K., Tejedor-Garcia, C., Cucchiarini, C., Strik, H. (2025) Enhancing GOP in CTC-Based Mispronunciation Detection with Phonological Knowledge. Proc. Interspeech 2025, 5068-5072, doi: 10.21437/Interspeech.2025-829
Accepted at Interspeech 2025.
 
 
## Acknowledgements
 
Part of the project Responsible AI for Voice Diagnostics (RAIVD) with file number NGF.1607.22.013 of the research program NGF AiNed Fellowship Grants, which is financed by the Dutch Research Council (NWO).
