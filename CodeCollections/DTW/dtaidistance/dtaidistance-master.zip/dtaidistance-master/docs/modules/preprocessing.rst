
.. automodule:: dtaidistance.preprocessing
   :members:
